#
# This file is part of the SCiLS Lab Python API client (scilslab).
#
# Copyright (C) 2020 - 2025, Bruker Daltonics GmbH & Co. KG, Bremen, Germany
# Contact: support.scils@bruker.com
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; version 2.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.
# If not, see <http://www.gnu.org/licenses/gpl-2.0.html>.
# SPDX-License-Identifier: GPL-2.0-only
#
# In addition to GPL2, this program can be provided by Bruker Daltonics
# under alternative licensing models. For more information on
# alternative options, please contact support.scils@bruker.com.
#
from typing import OrderedDict
import unittest

import numpy
import pandas as pd

from scilslab.session import LocalSession
from scilslab._tests.utils import CerebellaUUIDs
from scilslab._tests.utils import ScilsLabTestCase

class TestFeatureLists(ScilsLabTestCase):
    """
    A test class for the high level python Rest API.
    """

    def setUp(self):
        """
        Set up the client with a simple test file on the local host.
        """
        self._temp_dataset = self.temporaryDatasetFromArchive('cerebella.tar.gz')
        self._session = LocalSession(filename=self._temp_dataset.slx, retries=0)
        self._client = self._session.dataset_proxy
        self._auth = self._session.authentication_token

    def tearDown(self):
        """ Terminate the open session """
        self._session.close()
        self._temp_dataset.cleanup()

    def test_create_and_get_featurelists(self):
        """ Test that we can create and retrieve peak lists """

        feature_table = self._client.feature_table

        expected_feature_lists = OrderedDict()
        expected_feature_lists['id'] = ["", CerebellaUUIDs.pipeline1_aligned_peaks]
        expected_feature_lists['name'] = ["All Features", "Pipeline1-Aligned-Peaks"]
        expected_feature_lists['num_features'] = [8, 8]
        expected_feature_lists['has_mz_features'] = [True, True]
        expected_feature_lists['has_mobility_intervals'] = [False, False] 
        expected_feature_lists['has_ccs_features'] = [False, False]
        expected_feature_lists['has_external_features'] = [False, False]
        expected_feature_lists = pd.DataFrame(expected_feature_lists)
        
        feature_lists = feature_table.get_feature_lists()
        print(feature_lists)
        pd.testing.assert_frame_equal(feature_lists, expected_feature_lists)


        feature_list_id = feature_table.create_empty_feature_list("New feature list")
        regex = "^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$"
        self.assertRegex(feature_list_id, regex)

        expected_new_row = pd.DataFrame(
            [[feature_list_id, "New feature list", 0, False, False, False, False]],
            columns = ['id', 'name', 'num_features', 'has_mz_features', 'has_mobility_intervals', 'has_ccs_features', 'has_external_features']
        )
        expected_new_row.reset_index(drop=True, inplace=True)

        ftl = feature_table.get_feature_lists()
        print(ftl)
        new_row = ftl.iloc[[2]]
        new_row.reset_index(drop=True, inplace=True)

        pd.testing.assert_frame_equal(
            new_row,
            expected_new_row,
            check_index_type=False
        )

        with self.assertRaisesRegex(
                ValueError,
                ".*A feature list with the specified name already exists.*"):
            spectrum = feature_table.create_empty_feature_list("New feature list")

        new_list_id_2 = feature_table.create_empty_feature_list("New feature list", allow_duplicate_name=True)
        self.assertNotEqual(feature_list_id, new_list_id_2)

        self.assertEqual(2, sum(feature_table.get_feature_lists()['name'] == "New feature list") )

    def test_test_write_and_retrieve_mz_features(self):
        """Test that we can write and retrieve m/z features"""

        feature_table = self._client.feature_table

        feature_list_id = feature_table.create_empty_feature_list("TestMzFeatures")
        new_feature_ids = feature_table.write_mz_features(
            feature_list_id, ((100, 110),(3360, 3370))
        )

        self.assertEqual(2, len(new_feature_ids))
        self.assertEqual( -1, new_feature_ids[0])
        
        # Check that get_feature_intensities and get_ion_intensities give same result
        for mode in ('mean', 'max', 'sum', 'area'):
            for norm_id in ("",
                      CerebellaUUIDs.tic_norm,
                      CerebellaUUIDs.rms_norm,
                      CerebellaUUIDs.median_norm,
                      "Total Ion Count",
                      "Root Mean Square",
                      "Median"):

                feature_intensities_root_region = feature_table.get_feature_intensities(
                        new_feature_ids[1] ,
                        mode=mode,
                        normalization_id=norm_id)

                ion_intensities_root_region = self._client.get_ion_intensities(
                    3360,
                    3370,
                    mode=mode,
                    normalization_id=norm_id)
                
                numpy.testing.assert_array_equal(
                    feature_intensities_root_region.spot_ids,
                    ion_intensities_root_region.spot_ids
                )

                numpy.testing.assert_allclose(
                    feature_intensities_root_region.values,
                    ion_intensities_root_region.values
                )

                self.assertEqual(
                    feature_intensities_root_region.region_id,
                    'Regions')

                
                feature_intensities_region = feature_table.get_feature_intensities(
                        new_feature_ids[1] ,
                        CerebellaUUIDs.region_measurement2,
                        mode,
                        norm_id)
                ion_intensities_region =  self._client.get_ion_intensities(
                        3360,
                        3370,
                        CerebellaUUIDs.region_measurement2,
                        mode,
                        norm_id)
                
                numpy.testing.assert_array_equal(
                    feature_intensities_region.spot_ids,
                    ion_intensities_region.spot_ids
                )

                numpy.testing.assert_allclose(
                    feature_intensities_region.values,
                    ion_intensities_region.values
                )

                self.assertEqual(
                    feature_intensities_region.region_id,
                    CerebellaUUIDs.region_measurement2)

            # Check that normalization can be specified by name or by UUID
            for mode in ('mean', 'max', 'sum', 'area'):
                for norm_uuid, norm_name in zip([
                      CerebellaUUIDs.tic_norm,
                      CerebellaUUIDs.rms_norm,
                      CerebellaUUIDs.median_norm],
                      ["Total Ion Count",
                       "Root Mean Square",
                       "Median"]):
                    
                    feature_intensities_by_norm_uuid = feature_table.get_feature_intensities(
                        new_feature_ids[1] ,
                        mode=mode,
                        normalization_id=norm_uuid)
                    
                    feature_intensities_by_norm_name = feature_table.get_feature_intensities(
                        new_feature_ids[1] ,
                        mode=mode,
                        normalization_id=norm_name)
                    
                    numpy.testing.assert_array_equal(
                        feature_intensities_by_norm_uuid.spot_ids,
                        feature_intensities_by_norm_name.spot_ids)
                    
                    numpy.testing.assert_array_equal(
                        feature_intensities_by_norm_uuid.values,
                        feature_intensities_by_norm_name.values)
                    



    def test_test_write_and_retrieve_ccs_features(self):
        """Test that we can write and retrieve ccs features"""
        feature_table =self._client.feature_table

        ccs_featurelist_id = feature_table.create_empty_feature_list("CCSFeatureList")
        all_spots = self._client.get_region_spots('Regions')['spot_id']
        all_intensities = numpy.array(all_spots) / 10

        ccs_feature_id = feature_table.write_ccs_feature(
            ccs_featurelist_id,
            (3400.0, 3400.1),
            (1.01, 1.04),
            all_spots,
            all_intensities,
            "ccs feature"
        )

        ccs_feature_nonorm = feature_table.get_feature_intensities( ccs_feature_id)
        numpy.testing.assert_array_equal(
            ccs_feature_nonorm.spot_ids,
            all_spots
        )

        numpy.testing.assert_allclose(
            ccs_feature_nonorm.values,
            all_intensities
        )

        self.assertEqual(ccs_feature_nonorm.region_id, 'Regions')

        ccs_feature_nonorm_area = feature_table.get_feature_intensities(
            ccs_feature_id, mode='area'
        )
        numpy.testing.assert_array_equal(
            ccs_feature_nonorm_area.spot_ids,
            all_spots
        )

        numpy.testing.assert_allclose(
            ccs_feature_nonorm_area.values,
            all_intensities
        )

        ccs_feature_nonorm_sum = feature_table.get_feature_intensities(
            ccs_feature_id, mode='sum'
        )
        numpy.testing.assert_array_equal(
            ccs_feature_nonorm_sum.spot_ids,
            all_spots
        )

        numpy.testing.assert_allclose(
            ccs_feature_nonorm_sum.values,
            all_intensities
        )

        with self.assertRaisesRegex(
            ValueError,
            "Ion mobility feature intensities can only be retrieved for modes 'sum' or 'area'"):
            feature_table.get_feature_intensities(
                ccs_feature_id, mode='max')

        with self.assertRaisesRegex(
            ValueError,
            "Ion mobility feature intensities can only be retrieved for modes 'sum' or 'area'"):
            feature_table.get_feature_intensities(
                ccs_feature_id, mode='mean')

        ccs_feature_ticnorm = feature_table.get_feature_intensities(
            ccs_feature_id,
            normalization_id=CerebellaUUIDs.tic_norm)

        norm_values = self._client.get_spot_image(
            CerebellaUUIDs.tic_norm
            ).values

        numpy.testing.assert_array_equal(
            ccs_feature_ticnorm.spot_ids,
            all_spots
        )

        numpy.testing.assert_allclose(
            ccs_feature_ticnorm.values,
            all_intensities / norm_values
        )

        selected_spots = self._client.get_region_spots(
            CerebellaUUIDs.region_measurement1_01_WM
        )['spot_id']

        ccs_feature_selected_region = feature_table.get_feature_intensities(
            ccs_feature_id,
            region_id=CerebellaUUIDs.region_measurement1_01_WM
        )

        numpy.testing.assert_array_equal(
            ccs_feature_selected_region.spot_ids,
            selected_spots
        )

        numpy.testing.assert_allclose(
            ccs_feature_selected_region.values,
            all_intensities[numpy.array(selected_spots)]
        )

        ccs_feature_sel_reg_norm = feature_table.get_feature_intensities(
            ccs_feature_id,
            CerebellaUUIDs.region_measurement1_01_WM,
            normalization_id=CerebellaUUIDs.tic_norm
        )

        normalized_values = all_intensities / norm_values
        normalized_vals_sel_region = normalized_values[numpy.array(selected_spots)]

        numpy.testing.assert_array_equal(
            ccs_feature_sel_reg_norm.spot_ids,
            selected_spots
        )

        numpy.testing.assert_allclose(
            ccs_feature_sel_reg_norm.values,
            normalized_vals_sel_region
        )

    def test_test_write_and_retrieve_external_features(self):
        """Test that we can write and retrieve external features"""
        feature_table =self._client.feature_table
        ftl = feature_table.get_feature_lists()

        # add a new feature list with only external features
        external_featurelist_id = feature_table.create_empty_feature_list("ExternalFeatureList")
        all_spots = self._client.get_region_spots('Regions')['spot_id']
        all_intensities = numpy.array(all_spots) / 10

        # write external feature
        external_feature_id = feature_table.write_external_feature(
            external_featurelist_id,
            all_spots,
            all_intensities,
            "external feature"
        )

         # there is a new column 'has_external_features' and external features are included in the number of features reported for that feature list
        expected_new_row = pd.DataFrame(
            [[external_featurelist_id, "ExternalFeatureList", 1, False, False, False, True]],
            columns = ['id', 'name', 'num_features', 'has_mz_features', 'has_mobility_intervals', 'has_ccs_features', 'has_external_features']
        )
        expected_new_row.reset_index(drop=True, inplace=True)

        ftl = feature_table.get_feature_lists()
        new_row = ftl.iloc[[2]]
        new_row.reset_index(drop=True, inplace=True)
  
        pd.testing.assert_frame_equal(
            new_row,
            expected_new_row,
            check_index_type=False
        )

        # get_features include external features and mz_low and mz_high are numpy.nan 
        external_features = feature_table.get_features(external_featurelist_id)
        numpy.testing.assert_equal(external_features["mz_low"][0], numpy.nan)
        numpy.testing.assert_equal(external_features["mz_high"][0], numpy.nan)

        # mixed list
        mixed_featurelist_id = feature_table.create_empty_feature_list("MixedFeatureList")
        all_spots = self._client.get_region_spots('Regions')['spot_id']
        all_intensities = numpy.array(all_spots) / 10

        external_feature_id = feature_table.write_external_feature(
            mixed_featurelist_id,
            all_spots,
            all_intensities,
            "external feature"
        )

        mz_feature_id = feature_table.write_mz_features(
            mixed_featurelist_id, ((100, 110),(3360, 3370))
        )

        expected_feature_lists = OrderedDict()
        expected_feature_lists['id'] = ["", CerebellaUUIDs.pipeline1_aligned_peaks, external_featurelist_id, mixed_featurelist_id]
        expected_feature_lists['name'] = ["All Features", "Pipeline1-Aligned-Peaks", "ExternalFeatureList", "MixedFeatureList"]
        expected_feature_lists['num_features'] = [11, 8, 1, 2]
        expected_feature_lists['has_mz_features'] = [True, True, False, True]
        expected_feature_lists['has_mobility_intervals'] = [False, False, False, False] 
        expected_feature_lists['has_ccs_features'] = [False, False, False, False]
        expected_feature_lists['has_external_features'] = [True, False, True, True]
        expected_feature_lists = pd.DataFrame(expected_feature_lists)
        
        feature_lists = feature_table.get_feature_lists()
        print(feature_lists)
        pd.testing.assert_frame_equal(feature_lists, expected_feature_lists)


        # get_feature_intensities return values for external features, but do not get normalized
        intensities = feature_table.get_feature_intensities( external_feature_id )
        print(all_intensities)
        print(intensities.values)
        numpy.testing.assert_equal( len(intensities.values), len(all_spots) )
        numpy.testing.assert_allclose( intensities.values[2], all_intensities[2] )

        # apply a normalization and check that there is no change to the external featrue
        intensities = feature_table.get_feature_intensities( feature_id=external_feature_id, normalization_id=CerebellaUUIDs.tic_norm )
        numpy.testing.assert_equal( len(intensities.values), len(all_spots) )
        numpy.testing.assert_allclose( intensities.values[2], all_intensities[2] )

    def test_get_feature_intensities_with_invalid_id(self):
        feature_table = self._client.feature_table

        with self.assertRaisesRegex(
            ValueError,
            "'feature_id' must be non-negative"):
            feature_table.get_feature_intensities(
                -1)


    def test_get_features(self):
        """Test get_features functionality """
        ft = self._client.feature_table

        mz_only_feature_list_id = ft.create_empty_feature_list("MzOnly")

        emtpy_features = pd.DataFrame({
            'id': [],
            'mz_low': [],
            'mz_high': [],
            'name': [],
            'root_region_intensity': [],
            'color': [],
            'has_data': []
        })

        pd.testing.assert_frame_equal(
            emtpy_features,
            ft.get_features(mz_only_feature_list_id),
            check_dtype=False
        )
        

        ft.write_mz_features(
            mz_only_feature_list_id,
            ((100.0, 110.0),(3360.0,3370.0))
            )

        expected_mz_only = pd.DataFrame({
            'id': [8],
            'mz_low': [3360.0],
            'mz_high': [3370.0],
            'name': [""],
            'root_region_intensity': [numpy.nan],
            'color': [""],
            'has_data': [True]
        })

        pd.testing.assert_frame_equal(
            expected_mz_only,
            ft.get_features(mz_only_feature_list_id),
            check_dtype=False
        )

        all_spots = self._client.get_region_spots('Regions')['spot_id']
        all_intensities = numpy.array(all_spots) / 10

        ccs_only_feature_list_id = ft.create_empty_feature_list('mobilityOnly')
        ft.write_ccs_feature(
            ccs_only_feature_list_id,
            (3400.0, 3400.1),
            (1.01, 1.04),
            all_spots,
            all_intensities,
            "ccs feature"
            )

        ft.write_ccs_feature(
            ccs_only_feature_list_id,
            mz_interval=(3400.0, 3400.1),
            one_over_k0_interval=(1.1, 1.12),
            spot_ids=all_spots,
            values=all_intensities,
            name="ccs feature 2"
            )

        expected_mobility_only = pd.DataFrame({
            'id': [9,10],
            'mz_low': [3400.0, 3400.0],
            'mz_high': [3400.1, 3400.1],
            'one_over_k0_low': [1.01, 1.1],
            'one_over_k0_high': [1.04, 1.12],
            'name': ["ccs feature", "ccs feature 2"],
            'root_region_intensity': [numpy.nan, numpy.nan],
            'color': ["",""],
            'has_data': [True, True]
        })

        pd.testing.assert_frame_equal(
            expected_mobility_only,
            ft.get_features(ccs_only_feature_list_id),
            check_dtype=False
        )

        mixed_feature_list_id = ft.create_empty_feature_list('mixed')
        ft.write_mz_features(
            mixed_feature_list_id,
            ((100.0, 110.0),(3360.0,3370.0))
            )

        ft.write_ccs_feature(
            mixed_feature_list_id,
            mz_interval=(3400.0, 3400.1),
            one_over_k0_interval=(1.1,1.12),
            spot_ids=all_spots,
            values=all_intensities,
            name="ccs feature 2"
            )

        expected_mixed = pd.DataFrame({
            'id': [11, 12],
            'mz_low': [3360.0, 3400.0],
            'mz_high': [3370.0, 3400.1],
            'one_over_k0_low': [numpy.nan, 1.1],
            'one_over_k0_high': [numpy.nan, 1.12],
            'name': ["", "ccs feature 2"],
            'root_region_intensity': [numpy.nan, numpy.nan],
            'color': [ "", ""],
            'has_data': [True, True]
        })

        pd.testing.assert_frame_equal(
            expected_mixed,
            ft.get_features(mixed_feature_list_id),
            check_dtype=False
        )

        pd.testing.assert_frame_equal(
            expected_mixed,
            ft.get_features(mixed_feature_list_id, mode='area'),
            check_dtype=False
        )

        pd.testing.assert_frame_equal(
            expected_mixed,
            ft.get_features(mixed_feature_list_id, mode='sum'),
            check_dtype=False
        )

        expected_mixed_mean_max = expected_mixed
        expected_mixed_mean_max['has_data']= [True, False]

        pd.testing.assert_frame_equal(
            expected_mixed_mean_max,
            ft.get_features(mixed_feature_list_id, mode='max'),
            check_dtype=False
        )

        pd.testing.assert_frame_equal(
            expected_mixed_mean_max,
            ft.get_features(mixed_feature_list_id, mode='mean'),
            check_dtype=False
        )


        expected_feature_lists = pd.DataFrame({
            'id': [
                "",
                CerebellaUUIDs.pipeline1_aligned_peaks,
                mz_only_feature_list_id,
                ccs_only_feature_list_id,
                mixed_feature_list_id],
            'name': [
                "All Features",
                "Pipeline1-Aligned-Peaks",
                "MzOnly",
                "mobilityOnly",
                "mixed"
            ],
            'num_features': [13, 8, 1, 2, 2],
            'has_mz_features': [True, True, True, False, True],
            'has_mobility_intervals': [True, False, False, True, True],
            'has_ccs_features': [True, False, False, True, True],
            'has_external_features': [False, False, False, False, False]
        })

        ftl = ft.get_feature_lists()
        pd.testing.assert_frame_equal(
            expected_feature_lists,
            ftl,
            check_dtype=False
        )

    def test_write_user_column(self):
        ft = self._client.feature_table
        nan = numpy.nan

        # Write numeric column with list as parameters
        result = ft.write_column( "My list double column", [2,3,5], [22.0,33.0,55.0] )
        self.assertTrue(result)
        all_features = ft.get_features(include_visible_user_columns=True)
        self.assertEqual( all_features.shape, (8, 8))
        pd.testing.assert_series_equal(
            pd.Series([nan, nan, 22.0, 33.0, nan, 55.0, nan, nan], name='My list double column'),
            all_features['My list double column'],
            check_dtype=False
        )

        # Write numeric column with array as parameters
        result = ft.write_column(
            "My array double column",
            numpy.array([2,3,5]),
            numpy.array([22.0,33.0,55.0]) )
        self.assertTrue(result)
        all_features = ft.get_features(include_visible_user_columns=True)
        self.assertEqual( all_features.shape, (8, 9))
        pd.testing.assert_series_equal(
            pd.Series([nan, nan, 22.0, 33.0, nan, 55.0, nan, nan], name='My array double column'),
            all_features['My array double column'],
            check_dtype=False
        )

        # Write string column with Pandas series as parameters
        result = ft.write_column(
            "My series double column",
            pd.Series([2,3,5]),
            pd.Series([22.0,33.0,55.0]) )
        self.assertTrue(result)
        all_features = ft.get_features(include_visible_user_columns=True)
        self.assertEqual( all_features.shape, (8, 10))
        pd.testing.assert_series_equal(
            pd.Series([nan, nan, 22.0, 33.0, nan, 55.0, nan, nan], name='My series double column'),
            all_features['My series double column'],
            check_dtype=False
        )

        # Write string column with list as parameters
        result = ft.write_column(
            "My list string column",
            [2,3,5],
            ["twenty", "thirty", "fifty"] )
        self.assertTrue(result)
        all_features = ft.get_features(include_visible_user_columns=True)
        self.assertEqual( all_features.shape, (8, 11))
        pd.testing.assert_series_equal(
            pd.Series(["", "", "twenty", "thirty", "", "fifty", "", ""], name='My list string column'),
            all_features['My list string column'],
            check_dtype=False
        )

        # Write string column with array as parameters
        result = ft.write_column(
            "My array string column",
            [2,3,5],
            numpy.array(["twenty", "thirty", "fifty"], dtype=numpy.str_) )
        self.assertTrue(result)
        all_features = ft.get_features(include_visible_user_columns=True)
        self.assertEqual( all_features.shape, (8, 12))
        pd.testing.assert_series_equal(
            pd.Series(["", "", "twenty", "thirty", "", "fifty", "", ""], name='My array string column'),
            all_features['My array string column'],
            check_dtype=False
        )

        # Write string column with Pandas series as parameters and
        # visibility explicitly enabled
        result = ft.write_column(
            "My series string column",
            [2,3,5],
            pd.Series(["twenty", "thirty", "fifty"]),
            set_visible=True )
        self.assertTrue(result)
        all_features = ft.get_features(include_visible_user_columns=True)
        self.assertEqual( all_features.shape, (8, 13))
        pd.testing.assert_series_equal(
            pd.Series(["", "", "twenty", "thirty", "", "fifty", "", ""], name='My array string column'),
            all_features['My array string column'],
            check_dtype=False
        )

        # Overwriting existing column fails by default
        with self.assertRaisesRegex(
            ValueError,
            r".*Attempt to write an invalid feature table column: Column name already exists.*"):
                ft.write_column( "My list double column", [2,3,5], [22.0,33.0,55.0],  )

        # Overwriting existing column fails if explicitly disabled
        with self.assertRaisesRegex(
            ValueError,
            r".*Attempt to write an invalid feature table column: Column name already exists.*"):
                ft.write_column(
                    "My list double column",
                    [2,3,5], [22.0,33.0,55.0],
                     allow_duplicate_name=False )
                
        # Overwriting existing column succeeds if explicitly allowed
        result = ft.write_column(
            "My list double column",
            [2,3,5],
            [22.0,33.0,55.0],
             allow_duplicate_name=True )
        self.assertTrue(result)
        all_features = ft.get_features(include_visible_user_columns=True)
        self.assertEqual( all_features.shape, (8, 13))
        pd.testing.assert_series_equal(
            pd.Series([nan, nan, 22.0, 33.0, nan, 55.0, nan, nan], name='My list double column'),
            all_features['My list double column'],
            check_dtype=False
        )

        # Adding column with existing default name fails
        with self.assertRaisesRegex(
            ValueError,
            r".*Attempt to write an invalid feature table column: Column name already exists.*"):
                ft.write_column(
                    "Color",
                    [2,3,5], [22.0,33.0,55.0])
                
        #Adding column with existing default name succeeds if explicitly allowed
        result = ft.write_column(
                "Color",
                [2,3,5], [22.0,33.0,55.0],
                allow_duplicate_name=True)
        all_features = ft.get_features(include_visible_user_columns=True)
        self.assertEqual( all_features.shape, (8, 14))
        pd.testing.assert_series_equal(
            pd.Series([nan, nan, 22.0, 33.0, nan, 55.0, nan, nan], name='Color'),
            all_features.iloc[:,13],
            check_dtype=False
        )

        #Adding hidden column
        result = ft.write_column(
                "Hidden",
                [2,3,5], [22.0,33.0,55.0],
                set_visible=False)
        all_features = ft.get_features(include_visible_user_columns=True)
        self.assertEqual( all_features.shape, (8, 14))

        all_features = ft.get_features(include_all_user_columns=True)
        self.assertEqual( all_features.shape, (8, 15))
        pd.testing.assert_series_equal(
            pd.Series([nan, nan, 22.0, 33.0, nan, 55.0, nan, nan], name='Hidden'),
            all_features["Hidden"],
            check_dtype=False
        )

        # Writing fails if indices are not all integers or strings
        with self.assertRaisesRegex(
            TypeError,
            r".*Not all feature_ids are integer.*"):
                ft.write_column(
                    "Invalid indices",
                    [2,3.0,5], [22.0,33.0,55.0])
                
        # Writing fails if values are not all integers or strings
        with self.assertRaisesRegex(
            TypeError,
            r".*Values are not all numeric or string.*"):
                ft.write_column(
                    "Invalid indices",
                    [2,3,5], ["a","b",55.0])
                
        # Writing fails if values are not all integers or strings
        with self.assertRaisesRegex(
            TypeError,
            r".*Values are not all numeric or string.*"):
                ft.write_column(
                    "Invalid indices",
                    [2,3,5], ["a","b",list("c")])


class TestClientOneTwoThreeData(ScilsLabTestCase):
    """
    A test class for the high level python Rest API.
    """

    def setUp(self):
        """
        Set up the client with a simple test file on the local host.
        """
        self._temp_dataset = self.temporaryDatasetFromArchive('OneTwoThree.tar.gz')
        self._session = LocalSession(filename=self._temp_dataset.slx, retries=0)
        self._client = self._session.dataset_proxy

    def tearDown(self):
        """ Terminate the open session """
        self._session.close()
        self._temp_dataset.cleanup()

    def test_get_features_user_columns(self):
        """ Test that we can retrieve user columns in feature lists """

        feature_table = self._client.feature_table

        expected_full_features = pd.DataFrame({
            'id': [0, 1, 2],
            'mz_low': [1000.07325383305, 1000.209, 1000.709],
            'mz_high': [1000.26575809199, 1000.391, 1000.891],
            'name': ["", "", ""],
            'root_region_intensity': [numpy.nan, numpy.nan, numpy.nan],
            'color': ["#ff0000", "#33a02c", "#6a33c2"],
            'has_data': [True, True, True],
            'Misc': ["", "Very Interesting", "Not interesting"],
            'Average peak area - Regions - No Normalization':[
                0.120961964130402, 0.062709204852581, 0.0638817027211189
            ],
            'Overall maximum - Regions - No Normalization':[
                0.155626952648163, 0.146797478199005, 0.162060856819153
            ]
        })

        features_all_user_columns = feature_table.get_features(include_all_user_columns=True)
        pd.testing.assert_frame_equal(
            expected_full_features,
            features_all_user_columns,
            check_dtype=False
        )

        features_visible_user_columns = feature_table.get_features(include_visible_user_columns=True)
        pd.testing.assert_frame_equal(
            expected_full_features.iloc[:, [0,1,2,3,4,5,6,8]],
            features_visible_user_columns,
            check_dtype=False
        )

        features_no_user_columns = feature_table.get_features()
        features_visible_user_columns = feature_table.get_features(include_visible_user_columns=True)
        pd.testing.assert_frame_equal(
            expected_full_features.iloc[:, [0,1,2,3,4,5,6]],
            features_no_user_columns,
            check_dtype=False
        )
        

if __name__ == '__main__':
    unittest.main()
