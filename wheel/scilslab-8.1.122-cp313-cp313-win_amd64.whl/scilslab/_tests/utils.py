#
# This file is part of the SCiLS Lab Python API client (scilslab).
#
# Copyright (C) 2020 - 2025, Bruker Daltonics GmbH & Co. KG, Bremen, Germany
# Contact: support.scils@bruker.com
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; version 2.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.
# If not, see <http://www.gnu.org/licenses/gpl-2.0.html>.
# SPDX-License-Identifier: GPL-2.0-only
#
# In addition to GPL2, this program can be provided by Bruker Daltonics
# under alternative licensing models. For more information on
# alternative options, please contact support.scils@bruker.com.
#
"""
Utilities for the testsuite.
"""
from dataclasses import dataclass
import inspect
import io
import os
import sys
import tarfile
import tempfile
import unittest

from contextlib import contextmanager


@contextmanager
def captureoutput():
    """
    A method which temporary captures stdout and stderr output.

    Yield:
        (io.StringIO, io.StringIO): the standard output and standard error streams.
    Example:
        with captureoutput() as (out, err):
            print('hallo')
    """

    new_stdout, new_stderr = io.StringIO(), io.StringIO()
    old_stdout, old_stderr = sys.stdout, sys.stderr
    try:
        sys.stdout, sys.stderr = new_stdout, new_stderr
        yield sys.stdout, sys.stderr
    finally:
        sys.stdout, sys.stderr = old_stdout, old_stderr

class TemporarySCiLSDataset:
    """
    A class that wraps a temporary directory containing a SCiLS Lab dataset
    """
    def __init__(self, tempdir: tempfile.TemporaryDirectory):
        """Constructs the temporary dataset representation

        Args:
            tempdir (tempfile.TemporaryDirectory): The temporary
                directory containing a SCiLS Lab dataset
        """
        self._tempdir = tempdir
        self.directory_name = self._tempdir.name
        self.slx = None
        self.sbd = None

        for filename in os.listdir(self._tempdir.name):
            if filename.endswith('.slx'):
                self.slx = os.path.join(self._tempdir.name, filename)
            if filename.endswith('.sbd'):
                self.sbd = os.path.join(self._tempdir.name, filename)

    def cleanup(self):
        """Clean up the temporary directory
        """
        self._tempdir.cleanup()

class ScilsLabTestCase(unittest.TestCase):
    """
    A test class which wraps utilities to look for data files and
    to access them safely.
    """
    def assertTestDatasetExists(self, dataset):
        """
        Verify that a dataset exists and raise an exception otherwise.
        Accepts both full path and local path, referred to the default
        testdata directory.
        The file extension should be omitted, as the method will
        look for both the slx and sbd files.
        """
        for extension in ['.slx', '.sbd']:
            fullpath = self.getTestFileFullPath(
                dataset + extension)
            self.assertTrue(
                os.path.exists(fullpath) and os.path.isfile(fullpath))

    @staticmethod
    def temporaryDatasetFromArchive(
                origin: str,
                rename_to: str = None,
                tempdir_suffix: str = None
            ) -> TemporarySCiLSDataset:
        """Create a temporary dataset from a tar.gz file

        Creates a temporary dataset with a SCiLS Lab dataset from a
        tar.gz archive in the testdata directory.

        Args:
            origin (str): The filename of the archive
            rename_to (str, optional): Renames the SCiLS Dataset to
                this. Defaults to None.
            tempdir_suffix (str, optional): Passed through to the suffix
                parameter of tempfile.TemporaryDirectory(). Defaults to None.

        Returns:
            TemporarySCiLSDataset: [description]
        """

        temporary_directory = tempfile.TemporaryDirectory(prefix='sl_', suffix = tempdir_suffix)

        tarfile_fullname = ScilsLabTestCase.getTestFileFullPath(origin)
        with tarfile.open(tarfile_fullname) as archive:
            if hasattr(archive, 'extraction_filter'):
                archive.extractall(temporary_directory.name, filter='data')
            else:
                archive.extractall(temporary_directory.name)

        if rename_to is not None:
            for filename in os.listdir(temporary_directory.name):
                if filename.endswith('.slx'):
                    os.rename(
                        os.path.join(temporary_directory.name, filename),
                        os.path.join(temporary_directory.name, rename_to + '.slx')
                    )

                if filename.endswith('.sbd'):
                    os.rename(
                        os.path.join(temporary_directory.name, filename),
                        os.path.join(temporary_directory.name, rename_to + '.sbd')
                    )

        return TemporarySCiLSDataset(temporary_directory)


    @staticmethod
    def getTestFileFullPath(filename):
        """
        If filename is a local path, returns the full path associated
        to the test directory. If the filename is already
        a full path, returns the filename itself.

        Example:
           full_path = self.fullPath('basic.slx')
        """
        if os.path.isabs(filename):
            return filename
        else:
            return os.path.join(ScilsLabTestCase.getTestDataPath(), filename)

    @staticmethod
    def getTestDataPath():
        """
        Returns the full path to the test data.
        """
        current_dir = os.path.dirname(
            os.path.abspath(inspect.getfile(inspect.currentframe())))
        return os.path.join(current_dir, 'testdata')

@dataclass
class CerebellaUUIDs:
    tic_norm: str = "c7b3e3f6-9c92-434e-995a-0a2d89237e33"
    rms_norm: str = "973a3c3b-c77e-4ce6-9ca5-1fd596efbb9c"
    median_norm: str = "06e0e6cb-802c-4f57-a735-5ab738193771"
    pipeline1_aligned_peaks: str = "0d1d3452-4945-4101-8064-d63b12c45346"
    region_measurement1: str = "1722c605-19b8-4187-b15e-3de42fc3554a"
    region_measurement1_01: str = "092b1576-71f0-4df6-8d0d-d9c1f320adef"
    region_measurement1_01_WM: str = "003e23be-dd61-4bcc-b51b-641a7016efc3"
    region_measurement1_01_GM: str = "40f6de5c-6f12-4e7a-a616-287a989a5ce5"
    region_measurement2: str = "1a974c7b-3b65-4a9b-b719-ff146077224f"
    region_measurement2_01_GM: str = "b830f33b-7a2a-4887-844f-25fe8a2a549a"
    region_span: str = "7c2feece-3532-4867-8eea-86cc30e560e1"
    overview_image: str = "3c11a20d-1e60-40ff-bf05-a71ef5de297d"
    image_cerebellum_part2: str = "c7774e3e-301e-4d98-99fb-bf3a8aecccf7"
    image_cerebellum_part1: str = "da8aee89-f90a-4331-9f22-d049be4a1919"
    image_external_multires: str = "f7b55f06-8031-41cf-b0c3-1bdd5ee63be3"