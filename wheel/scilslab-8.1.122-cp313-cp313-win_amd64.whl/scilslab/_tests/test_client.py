#
# This file is part of the SCiLS Lab Python API client (scilslab).
#
# Copyright (C) 2020 - 2025, Bruker Daltonics GmbH & Co. KG, Bremen, Germany
# Contact: support.scils@bruker.com
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; version 2.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.
# If not, see <http://www.gnu.org/licenses/gpl-2.0.html>.
# SPDX-License-Identifier: GPL-2.0-only
#
# In addition to GPL2, this program can be provided by Bruker Daltonics
# under alternative licensing models. For more information on
# alternative options, please contact support.scils@bruker.com.
#
import itertools
import textwrap
from tokenize import Double
import unittest
from unittest.mock import patch

import numpy
import pandas

from scilslab.client import DatasetProxy
from scilslab.session import LocalSession
from scilslab.types import Point
from scilslab.types import IntensitySpotImage
from scilslab.types import ScoreSpotImage
from scilslab.types import RGBSpotImage
from scilslab._tests.utils import CerebellaUUIDs
from scilslab._tests.utils import captureoutput
from scilslab._tests.utils import ScilsLabTestCase

class TestClientCerebellaData(ScilsLabTestCase):
    """
    A test class for the high level python Rest API.
    """

    @classmethod
    def setUpClass(cls):
        """
        Set up the client with a simple test file on the local host.
        """
        cls._temp_dataset = cls.temporaryDatasetFromArchive('cerebella.tar.gz')
        cls._session = LocalSession(filename=cls._temp_dataset.slx, retries=0)
        cls._client = cls._session.dataset_proxy
        cls._auth = cls._session.authentication_token

    @classmethod
    def tearDownClass(cls):
        """ Terminate the open session """
        cls._session.close()
        cls._temp_dataset.cleanup()

    def test_client_constructor_invalid_arguments(self):
        """ Test the Client constructor raises for invalid arguments """
        with self.assertRaises(TypeError):
            DatasetProxy(authentication_token="foo", hostname=123)
        with self.assertRaises(ConnectionError):
            DatasetProxy(authentication_token="foo", port="foo")
        with self.assertRaises(ConnectionError):
            DatasetProxy(authentication_token=123, port="foo")
        # These hostnames are not legit but connection errors are raised,
        # as server with the given hostname can not be found.
        with self.assertRaises(ConnectionError):
            DatasetProxy(authentication_token="foo", hostname="host:")
        with self.assertRaises(ConnectionError):
            DatasetProxy(authentication_token="foo", hostname="")
        with self.assertRaises(ConnectionError):
            DatasetProxy(authentication_token="foo", hostname="//127.0.0.1")
        with self.assertRaisesRegex(
                ConnectionError,
                "Cannot establish a working connection.*Authentication failed.*"):
            DatasetProxy(authentication_token="foo")

    def test_client_retries_sleep_args(self):
        """ Test that negative retries and sleeps are dealed with """
        # Negtive values are capped to 0. Verify that the client works.
        client = DatasetProxy(
            authentication_token=self._auth, retries=-1, sleep=-10)
        self.assertIn('SCiLS REST API', client.get_server_version())

    def test_get_server_version(self):
        """ Test that we can retrieve the version correctly """
        version = self._client.get_server_version()
        self.assertIn('SCiLS REST API', version)

    def test_get_license_info(self):
        """ Test that we can retrieve the license information correctly """
        version = self._client.get_license_info()
        self.assertTrue(len(version) > 0)

    def test_get_file_info(self):
        """ Test that we can retrieve the license information correctly """
        fileinfo = self._client.get_file_info()
        self.assertEqual(len(fileinfo), 2)
        self.assertEqual(fileinfo.filepath, self._temp_dataset.slx)
        self.assertEqual(fileinfo.uuid, '4dec00e4-b263-4dc0-b926-243167961237')

    def test_get_normalizations(self):
        """ Test that we can retrieve the normalizations """
        # This data set contains 3 normalizations: Median, Total Ion Count and
        # Root Mean Square.
        normalizations = self._client.get_normalizations()
        self.assertIsInstance(normalizations, (dict))
        self.assertEqual(len(normalizations), 3)
        for entry in ["Median", "Total Ion Count", "Root Mean Square"]:
            self.assertIn(entry, normalizations.values())
        # Reference ids from data inspection.
        self.assertEqual(
            normalizations[CerebellaUUIDs.median_norm],
            'Median')
        self.assertEqual(
            normalizations[CerebellaUUIDs.tic_norm],
            'Total Ion Count')
        self.assertEqual(
            normalizations[CerebellaUUIDs.rms_norm],
            'Root Mean Square')

    def test_get_region_tree(self):
        """ Test that we can get the region tree """
        region_tree = self._client.get_region_tree()
        # Compare print with a reference text.
        with captureoutput() as (out, err):
            region_tree.print()
        reference = textwrap.dedent("""\
            Name: Regions
            Id: Regions
            Number of spots: 2336
            Attributes: {'Date': '2024-02-08 11:13:59'}


              Name: measurement1
              Id: 1722c605-19b8-4187-b15e-3de42fc3554a
              Number of spots: 1132
              Attributes: {'Date': '2024-02-08 11:13:59', 'DateAtt': '2020-03-01 10:23:51'}


                Name: 01
                Id: 092b1576-71f0-4df6-8d0d-d9c1f320adef
                Number of spots: 1132
                Attributes: {'Date': '2024-02-08 11:13:59'}


                  Name: GM
                  Id: 40f6de5c-6f12-4e7a-a616-287a989a5ce5
                  Number of spots: 174
                  Attributes: {'BooleanAtt': 'true', 'Date': '2020-04-06 10:48:43', 'NumericAtt': '2', 'TextAtt': 'GM'}


                  Name: WM
                  Id: 003e23be-dd61-4bcc-b51b-641a7016efc3
                  Number of spots: 220
                  Attributes: {'Date': '2020-04-06 10:47:13'}


              Name: measurement2
              Id: 1a974c7b-3b65-4a9b-b719-ff146077224f
              Number of spots: 1204
              Attributes: {'Date': '2024-02-08 11:13:59', 'DateAtt': '2020-03-02 08:16:32'}


                Name: 01
                Id: e08aac6b-7624-4076-bbeb-b6f1f1c1a782
                Number of spots: 1204
                Attributes: {'Date': '2024-02-08 11:13:59'}


                  Name: GM
                  Id: b830f33b-7a2a-4887-844f-25fe8a2a549a
                  Number of spots: 237
                  Attributes: {'BooleanAtt': 'false', 'Date': '2020-04-06 10:49:12', 'NumericAtt': '1', 'TextAtt': 'GM'}


                Name: WM
                Id: 5dc0f40f-1b01-4f22-9207-d23e6a0ac649
                Number of spots: 232
                Attributes: {'Date': '2020-04-06 10:47:53'}


              Name: span
              Id: 7c2feece-3532-4867-8eea-86cc30e560e1
              Number of spots: 759
              Attributes: {'Date': '2020-04-06 10:49:46'}""")
        self.assertIn(reference, out.getvalue())
        # Retrieve a flattened out list of regions.
        regions = region_tree.get_all_regions()
        self.assertEqual(len(regions), 10)
        names = [r.name for r in regions]
        self.assertEqual(
            sorted(names),
            sorted(
                ["Regions",
                 "Regions/measurement1",
                 "Regions/measurement1/01",
                 "Regions/measurement1/01/WM",
                 "Regions/measurement1/01/GM",
                 "Regions/measurement2",
                 "Regions/measurement2/01",
                 "Regions/measurement2/01/GM",
                 "Regions/measurement2/WM",
                 "Regions/span"]))
    def test_get_spectrum(self):
        """ Test the spectrum getter """
        # The dataset has 2336 spots. Sample extreme points.
        spectrum = self._client.get_spectrum(0)
        spectrum = self._client.get_spectrum(2335, CerebellaUUIDs.median_norm)

        # Values verified with visual inspection with scilslab.
        spectrum = self._client.get_spectrum(9)
        # m/z upper and lower bound.
        self.assertAlmostEqual(spectrum['mz'][0], 3350.0)
        self.assertAlmostEqual(spectrum['mz'][-1], 3430.0)
        self.assertEqual(len(spectrum['mz']), 60)

        spectrum_rebinned = self._client.get_spectrum(9, rebinned=True)
        # m/z upper and lower bound.
        self.assertAlmostEqual(spectrum_rebinned['mz'][0], 3350.0)
        self.assertAlmostEqual(spectrum_rebinned['mz'][-1], 3430.0)
        self.assertEqual(len(spectrum_rebinned['mz']), 60)
        self.assertAlmostEqual(spectrum_rebinned['intensities'][0], 5.0728793, delta=1e-6)
        self.assertAlmostEqual(spectrum_rebinned['intensities'][2], 7.149979, delta=1e-6)

        spectrum_rebinned10 = self._client.get_spectrum(10, rebinned=True)
        self.assertEqual(len(spectrum_rebinned10['mz']), 60)
        # Peak position.
        peak_mz = spectrum['mz'][numpy.argmax(spectrum['intensities'])]
        self.assertAlmostEqual(peak_mz, 3424.57627118644)
        self.assertAlmostEqual(
            numpy.max(spectrum['intensities']), 40.1519546508789)
        
        # Test that normalization can be specified by name or by uuid
        for norm_uuid, norm_name in zip(
            [
                CerebellaUUIDs.median_norm,
                CerebellaUUIDs.tic_norm,
                CerebellaUUIDs.rms_norm
            ],
            [
                "Median", "Total Ion Count", "Root Mean Square"
            ]):

            spectrum_by_norm_id = self._client.get_spectrum(9, normalization_id=norm_uuid)
            spectrum_by_norm_name = self._client.get_spectrum(9, norm_name)

            numpy.testing.assert_array_equal(
                spectrum_by_norm_id['intensities'],
                spectrum_by_norm_name['intensities']
                )
            
            numpy.testing.assert_array_equal(
                spectrum_by_norm_id['mz'],
                spectrum_by_norm_name['mz']
                )

        # Test that we get failures out of the limits.
        with self.assertRaisesRegex(
                ValueError,
                ".*Attempt to access spectrum with a spot id out of boundaries.*"):
            spectrum = self._client.get_spectrum(-1)
            
        with self.assertRaisesRegex(
                ValueError,
                ".*Attempt to access spectrum with a spot id out of boundaries.*"):
            spectrum = self._client.get_spectrum(2336)

        # Check that the client is still reachable.
        self.assertTrue(self._client.get_server_version())



    def test_get_mean_spectrum(self):
        """ Test the mean spectrum getter """
        # Reference values determined with scilslab.
        mean_spectrum = self._client.get_mean_spectrum(
            region_id=CerebellaUUIDs.region_measurement1,
            normalization_id=CerebellaUUIDs.tic_norm)
        self.assertAlmostEqual(
            numpy.max(mean_spectrum['intensities']), 43.3464813232)
        self.assertAlmostEqual(
            mean_spectrum['mz'][numpy.argmax(mean_spectrum['intensities'])],
            3424.57627118644)
        # Get the mean spectrum for the other normalizations, and verify that
        # they differ (regression for an old bug).
        mean_spectrum_median = self._client.get_mean_spectrum(
            region_id=CerebellaUUIDs.region_measurement1,
            normalization_id=CerebellaUUIDs.median_norm)
        self.assertNotAlmostEqual(
            numpy.max(mean_spectrum['intensities']),
            numpy.max(mean_spectrum_median['intensities']))
        mean_spectrum_rms = self._client.get_mean_spectrum(
            region_id=CerebellaUUIDs.region_measurement1,
            normalization_id=CerebellaUUIDs.rms_norm)
        self.assertNotAlmostEqual(
            numpy.max(mean_spectrum['intensities']),
            numpy.max(mean_spectrum_rms['intensities']))
        self.assertNotAlmostEqual(
            numpy.max(mean_spectrum_median['intensities']),
            numpy.max(mean_spectrum_rms['intensities']))
        
        # Test that normalization can be specified by name or by uuid
        for norm_uuid, norm_name in zip(
            [
                CerebellaUUIDs.median_norm,
                CerebellaUUIDs.tic_norm,
                CerebellaUUIDs.rms_norm
            ],
            [
                "Median", "Total Ion Count", "Root Mean Square"
            ]):

            mean_spectrum_by_norm_id = self._client.get_mean_spectrum(
                region_id=CerebellaUUIDs.region_measurement1,
                normalization_id=norm_uuid)
            
            mean_spectrum_by_norm_name = self._client.get_mean_spectrum(
                region_id=CerebellaUUIDs.region_measurement1,
                normalization_id=norm_name)

            numpy.testing.assert_array_equal(
                mean_spectrum_by_norm_id['intensities'],
                mean_spectrum_by_norm_name['intensities']
                )
            
            numpy.testing.assert_array_equal(
                mean_spectrum_by_norm_id['mz'],
                mean_spectrum_by_norm_name['mz']
                )


    def test_get_region_spots(self):
        """ Test the regin spot getter """
        # Retrieve the spot from the measurement1 region
        spots = self._client.get_region_spots(
            region_id=CerebellaUUIDs.region_measurement1)
        self.assertIsInstance(spots, (dict))
        # Check that the dictionary contains only the wished data.
        self.assertEqual(
            sorted(['spot_id', 'raster', 'x', 'y', 'z']),
            sorted(list(spots.keys())))
        self.assertEqual(len(spots["spot_id"]), 1132)
        self.assertEqual(len(spots["raster"]), 1132)
        self.assertEqual(len(spots["x"]), 1132)
        self.assertEqual(len(spots["y"]), 1132)
        self.assertEqual(len(spots["z"]), 1132)
        # Retrieve the spots for the subregion 01. They should be identical
        # since the subregion is equal to the paret region.
        spots_01 = self._client.get_region_spots(
            region_id=CerebellaUUIDs.region_measurement1_01)
        self.assertEqual(spots['spot_id'], spots_01['spot_id'])
        self.assertEqual(spots['raster'], spots_01['raster'])
        for key in ['x', 'y', 'z']:
            self.assertAlmostEqual(
                numpy.linalg.norm(spots[key] - spots_01[key]), 0.0)
        # Check that all spots belong to the raster 0.
        self.assertSequenceEqual(spots['raster'], [0] * 1132)

    def test_get_and_write_labels(self):
        """ Test that we can retrieve labels and write labels to file """
        regex = "^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$"
        # This dataset has two labels to start with.
        labels = self._client.get_labels()
        self.assertEqual(len(labels), 2)
        # Write some label.
        test_label = {1: 1, 2: 1, 3: 5, 4: 5, 5: 2}
        label_id = self._client.write_label('Test label', test_label)
        self.assertRegex(label_id, regex)
        read_labels = self._client.get_labels()
        self.assertEqual(label_id, read_labels[2].id)
        self.assertEqual(len(read_labels), 3)
        self.assertEqual('Test label', read_labels[2].name)
        self.assertEqual(test_label, read_labels[2].spot_label)
        # Write another one.
        test_label_2 = {10: 3, 20: 3}
        label_2_id = self._client.write_label('Test label 2', test_label_2)
        self.assertRegex(label_2_id, regex)
        read_labels = self._client.get_labels()
        self.assertEqual(len(read_labels), 4)
        self.assertEqual(label_id, read_labels[2].id)
        self.assertEqual(test_label, read_labels[2].spot_label)
        self.assertEqual(label_2_id, read_labels[3].id)
        self.assertEqual('Test label 2', read_labels[3].name)
        self.assertEqual(test_label_2, read_labels[3].spot_label)

    def test_get_region_attributes(self):
        """ Test that we can retrieve region attributes """
        attributes = self._client.get_region_attributes(
            region_id=CerebellaUUIDs.region_measurement2_01_GM)
        
        self.assertEqual(len(attributes), 4)
        self.assertEqual(attributes['Date'], '2020-04-06 10:49:12')
        self.assertEqual(attributes['NumericAtt'], '1')
        self.assertEqual(attributes['BooleanAtt'], 'false')
        self.assertEqual(attributes['TextAtt'], 'GM')


    def test_get_region_polygons(self):
        """ Test that we can retrieve the polygons """
        polygons = self._client.get_region_polygons(
            region_id=CerebellaUUIDs.region_measurement2_01_GM)
        # Polygons are represented as list of list of points.
        # In this region we have only one polygon.
        self.assertEqual(len(polygons), 1)
        for point in polygons[0]:
            self.assertIsInstance(point, (Point))
        # Check against reference value obtained by inspecting a sef file export.
        self.assertAlmostEqual(polygons[0][0].x, 4300.43)
        self.assertAlmostEqual(polygons[0][0].y, 684.833)

    def test_get_spectra_matrix(self):
        """ Test that we can retrieve a spectra matrix """
        # Retrieve the first 10 spectra.
        spectra_matrix = self._client.get_spectra_matrix(
            spot_ids=tuple(range(10)))
        # Retrieve the first spectrum using the get_spectrum method and compare
        # the results.
        for i in range(10):
            spectrum = self._client.get_spectrum(i)
            # Check the data dimensionality.
            self.assertEqual(
                spectra_matrix.intensities.shape, (10, len(spectrum['mz'])))
            # Check that the mz and intensities obtained with the 2 methods
            # are equivalent.
            mz_diff = numpy.array(spectra_matrix.mz) - numpy.array(spectrum['mz'])
            self.assertAlmostEqual(numpy.linalg.norm(mz_diff), 0.0)
            intensity_diff = (
                    spectra_matrix.intensities[i, :] - spectrum['intensities'])
            self.assertAlmostEqual(numpy.linalg.norm(mz_diff), 0.0)
            self.assertAlmostEqual(numpy.linalg.norm(intensity_diff), 0.0)

        # Test that normalization can be specified by name or by uuid
        for norm_uuid, norm_name in zip(
            [
                CerebellaUUIDs.median_norm,
                CerebellaUUIDs.tic_norm,
                CerebellaUUIDs.rms_norm
            ],
            [
                "Median", "Total Ion Count", "Root Mean Square"
            ]):

            spectra_matrix_by_norm_id = self._client.get_spectra_matrix(
                spot_ids=tuple(range(10)), normalization_id=norm_uuid)
            
            spectra_matrix_by_norm_name = self._client.get_spectra_matrix(
                spot_ids=tuple(range(10)), normalization_id=norm_name)
            
            numpy.testing.assert_array_equal(
                spectra_matrix_by_norm_id.intensities,
                spectra_matrix_by_norm_name.intensities
            )

            numpy.testing.assert_array_equal(
                spectra_matrix_by_norm_id.mz,
                spectra_matrix_by_norm_name.mz
            )

            numpy.testing.assert_array_equal(
                spectra_matrix_by_norm_id.spot_ids,
                spectra_matrix_by_norm_name.spot_ids
            )
        
        # Test the pandas data frame export.
        data = spectra_matrix.to_data_frame()
        self.assertIsInstance(data, (pandas.DataFrame))
        # Get and check some spectra.
        diff = numpy.linalg.norm(data['spot 0'] - spectra_matrix.intensities[0, :])
        self.assertAlmostEqual(numpy.linalg.norm(diff), 0.0)
        diff = numpy.linalg.norm(data['spot 1'] - spectra_matrix.intensities[1, :])
        self.assertAlmostEqual(numpy.linalg.norm(diff), 0.0)
        diff = numpy.linalg.norm(data['mz'] - spectra_matrix.mz)
        self.assertAlmostEqual(numpy.linalg.norm(diff), 0.0)

        # Test that we get failures out of the limits.
        with self.assertRaises(TypeError):
            spectrum = self._client.get_spectra_matrix([-1, 0])
        with self.assertRaisesRegex(
                ValueError,
                ".*Attempt to access spectrum with a spot id out of boundaries.*"):
            spectrum = self._client.get_spectra_matrix([0, 2336])

        with self.assertRaisesRegex(
                ValueError,
                ".*Spot ids are not unique*"):
            spectrum = self._client.get_spectra_matrix([0, 0, 1])

        with self.assertRaisesRegex(
                ValueError,
                ".*Spot ids are not sorted in increasing order*"):
            spectrum = self._client.get_spectra_matrix([0, 3, 2])

        # Check that the client is still reachable.
        self.assertTrue(self._client.get_server_version())

    def test_get_ion_images(self):
        """ Test that we can retrieve the ion images """
        # Retrieve the images from the Measurement 1 region.
        ion_images = self._client.get_ion_images(
            min_mz=3351,
            max_mz=3359,
            region_id=CerebellaUUIDs.region_measurement1,
            mode='sum',
            normalization_id='')
        # We should have one image with an intensity entry per each
        # spot in the rectangle.
        self.assertEqual(len(ion_images), 1)
        image = ion_images[0]
        self.assertSequenceEqual(
            (image.rectangle.height, image.rectangle.width),
            image.values.shape)
        # Reference value dataset inspection.
        max_value = numpy.nanmax(image.values)
        self.assertAlmostEqual(max_value, 179.054367065)

        # Test for proper initialization of arguments, using Total Ion Count Norm
        ion_images_tic = self._client.get_ion_images(
            3351,
            3359,
            CerebellaUUIDs.region_measurement1,
            'sum',
            CerebellaUUIDs.tic_norm)
        # We should have one image with an intensity entry per each
        # spot in the rectangle.
        self.assertEqual(len(ion_images_tic), 1)
        image_tic = ion_images_tic[0]
        self.assertSequenceEqual(
            (image_tic.rectangle.height, image_tic.rectangle.width),
            image_tic.values.shape)
        # Reference value dataset inspection.
        max_value = numpy.nanmax(image_tic.values)
        self.assertAlmostEqual(max_value, 144.328384399)

        # Test that numpy calculations cause no warnings
        # due to signalling NaN's not properly converted to
        # numpy.nan
        with numpy.testing.assert_no_warnings():
            image_subtracted = image.values - 0.1

        # Test that image contains NaN's
        self.assertTrue( numpy.isnan(image.values).any() )

    def test_get_ion_images_invalid_out_of_bounds_intervals(self):
        # Interval is partially outside of m/z axis
        mz_low = 3340
        mz_high = 3360

        with self.assertRaisesRegex(
            ValueError,
            "The specified interval contains no values."):
            self._client.get_ion_images(mz_low, mz_high, mode="mean")

        with self.assertRaisesRegex(
            ValueError,
            "The specified interval contains no values."):
            self._client.get_ion_images(mz_low, mz_high, mode="max")

        with self.assertRaisesRegex(
            ValueError,
            "The specified interval contains no values."):
            self._client.get_ion_images(mz_low, mz_high, mode="sum")

        with self.assertRaisesRegex(
            ValueError,
            "The specified interval contains no values."):
            self._client.get_ion_images(mz_low, mz_high, mode="area")

    def test_get_ion_images_invalid_between_bin_intervals(self):
        # Interval is between two bins
        mz_low = 3360
        mz_high = 3360.5

        with self.assertRaisesRegex(
            ValueError,
            "The specified interval contains no values."):
            self._client.get_ion_images(mz_low, mz_high, mode="mean")

        with self.assertRaisesRegex(
            ValueError,
            "The specified interval contains no values."):
            self._client.get_ion_images(mz_low, mz_high, mode="max")

        with self.assertRaisesRegex(
            ValueError,
            "The specified interval contains no values."):
            self._client.get_ion_images(mz_low, mz_high, mode="sum")

        # Area mode ist valid under these conditions
        try:
            self._client.get_ion_images(mz_low, mz_high, mode="area")
        except ValueError:
            self.fail(" Area mode raised ValueError for in-between-bin interval")

    def test_get_ion_intensities(self):
        """ Test that we can retrieve the ion intensities """
        # The different normalizations are: No Normalization, Median,
        # Total Ion Count and Root Mean Square.
        norms_ids = ['',
                     CerebellaUUIDs.median_norm,
                     CerebellaUUIDs.tic_norm,
                     CerebellaUUIDs.rms_norm]
        max_intensity_values = [179.054367065, 142.269927979,
                                144.328384399, 140.364746094]

        for norm, max_intensity_value in zip(norms_ids, max_intensity_values):
            # Retrieve the intensities from the Measurement 1 region.
            ion_intensities = self._client.get_ion_intensities(
                min_mz=3351,
                max_mz=3359,
                region_id=CerebellaUUIDs.region_measurement1,
                mode='sum',
                normalization_id=norm)
            self.assertEqual(len(ion_intensities), 3)
            # The region has 1132 spots.
            # We should have the spot entry with its corresponding intensity value.
            self.assertEqual(len(ion_intensities.spot_ids), 1132)
            self.assertEqual(len(ion_intensities.values), 1132)
            # Reference value dataset inspection.
            max_value = numpy.max(ion_intensities.values)
            self.assertAlmostEqual(max_value, max_intensity_value)

        for norm_uuid, norm_name in zip(
            [
                CerebellaUUIDs.median_norm,
                CerebellaUUIDs.tic_norm,
                CerebellaUUIDs.rms_norm
            ],
            [
                "Median", "Total Ion Count", "Root Mean Square"
            ]):

            ion_intensities_by_norm_uuid = self._client.get_ion_intensities(
                min_mz=3351,
                max_mz=3359,
                region_id=CerebellaUUIDs.region_measurement1,
                mode='sum',
                normalization_id=norm_uuid)
            
            ion_intensities_by_norm_name = self._client.get_ion_intensities(
                min_mz=3351,
                max_mz=3359,
                region_id=CerebellaUUIDs.region_measurement1,
                mode='sum',
                normalization_id=norm_name)
            
            numpy.testing.assert_array_equal(
                ion_intensities_by_norm_uuid.spot_ids,
                ion_intensities_by_norm_name.spot_ids
            )
            
            numpy.testing.assert_array_equal(
                ion_intensities_by_norm_uuid.values,
                ion_intensities_by_norm_name.values
            )
            

            

    def test_get_ion_intensities_invalid_out_of_bounds_intervals(self):
        # Interval is partially outside of m/z axis
        mz_low = 3340
        mz_high = 3360

        with self.assertRaisesRegex(
            ValueError,
            "The specified interval contains no values."):
            self._client.get_ion_intensities(mz_low, mz_high, mode="mean")

        with self.assertRaisesRegex(
            ValueError,
            "The specified interval contains no values."):
            self._client.get_ion_intensities(mz_low, mz_high, mode="max")

        with self.assertRaisesRegex(
            ValueError,
            "The specified interval contains no values."):
            self._client.get_ion_intensities(mz_low, mz_high, mode="sum")

        with self.assertRaisesRegex(
            ValueError,
            "The specified interval contains no values."):
            self._client.get_ion_intensities(mz_low, mz_high, mode="area")

    def test_get_ion_intensities_invalid_between_bin_intervals(self):
        # Interval is between two bins
        mz_low = 3360
        mz_high = 3360.5

        with self.assertRaisesRegex(
            ValueError,
            "The specified interval contains no values."):
            self._client.get_ion_intensities(mz_low, mz_high, mode="mean")

        with self.assertRaisesRegex(
            ValueError,
            "The specified interval contains no values."):
            self._client.get_ion_intensities(mz_low, mz_high, mode="max")

        with self.assertRaisesRegex(
            ValueError,
            "The specified interval contains no values."):
            self._client.get_ion_intensities(mz_low, mz_high, mode="sum")

        # Area mode ist valid under these conditions
        try:
            self._client.get_ion_intensities(mz_low, mz_high, mode="area")
        except ValueError:
            self.fail(" Area mode raised ValueError for in-between-bin interval")


    def test_get_index_images(self):
        """ Test that we can retrieve the index images """
        # Retrieve the images from the Measurement1 region.
        index_images = self._client.get_index_images(
            region_id=CerebellaUUIDs.region_measurement1)
        # We should have one image with an intensity entry per each
        # spot in the rectangle.
        self.assertEqual(len(index_images), 1)
        image = index_images[0]
        self.assertSequenceEqual(
            (image.rectangle.height, image.rectangle.width),
            image.values.shape)
        # Verify that we have multiple invalid spots labelled as -1 and only
        # one occurence of any other id>0.
        spot_ids = image.values
        self.assertEqual(numpy.min(spot_ids), -1)
        self.assertEqual(numpy.max(spot_ids), 1131)

        unique, counts = numpy.unique(spot_ids, return_counts=True)
        occurences = dict(zip(unique, counts))
        self.assertIn(-1, occurences.keys())
        self.assertGreater(occurences[-1], 1)
        for i in range(1132):
            self.assertEqual(occurences[i], 1)

    def test_consistent_index_ion_images(self):
        """
        Test that the information retrieved from the two images is consistent.
        """
        ion_images = self._client.get_ion_images(
            min_mz=3351,
            max_mz=3359,
            region_id=CerebellaUUIDs.region_measurement1)
        values = ion_images[0].values
        index_images = self._client.get_index_images(
            region_id=CerebellaUUIDs.region_measurement1)
        spot_ids = index_images[0].values
        # Shape check.
        self.assertSequenceEqual(values.shape, spot_ids.shape)
        # Check that the invalid spots correspond to an intensity of nan.
        numpy.testing.assert_allclose(numpy.isnan(values), spot_ids == -1)

    def test_client_api_version(self):
        """ Test the getter for the client api version """
        self.assertEqual(
            DatasetProxy.client_version,
            self._client.get_server_version())

    def test_connection_fails_for_api_mismatch(self):
        """ Test connection to a Server with a different API version """
        with patch('scilslab._cppserialization.apiVersionString') as mock:
            mock.return_value = "SCiLS REST API v4.0"
            # Connection should fail.
            with self.assertRaisesRegex(
                    ValueError,
                    "ERROR: Client and Server use different API major versions. Client SCiLS REST API v4.0. Server SCiLS REST API"
                    ):
                DatasetProxy(
                    authentication_token=self._auth,
                    hostname="127.0.0.1")

    def test_default_initialization(self):
        """ Test that the right output is returned for default initialization """
        # Retrieve the images from the root region.
        ion_images = self._client.get_ion_images(
            min_mz=3351,
            max_mz=3359,
            region_id='Regions',
            mode='area',
            normalization_id='')
        ion_images_none = self._client.get_ion_images(
            min_mz=3351,
            max_mz=3359,
            region_id=None,
            mode=None,
            normalization_id=None)
        # We should have one image with an intensity entry per each
        # spot in the rectangle.
        self.assertEqual(len(ion_images), len(ion_images_none))
        image = ion_images[0]
        image_none = ion_images_none[0]
        # Reference value dataset inspection.
        max_value = numpy.nanmax(image.values)
        max_value_none = numpy.nanmax(image_none.values)
        self.assertEqual(max_value, max_value_none)

        # Retrieve the intensities from the root region.
        ion_intensities = self._client.get_ion_intensities(
            min_mz=3351,
            max_mz=3359,
            region_id='Regions',
            mode='area',
            normalization_id='')
        ion_intensities_none = self._client.get_ion_intensities(
            min_mz=3351,
            max_mz=3359,
            region_id=None,
            mode=None,
            normalization_id=None)
        self.assertEqual(len(ion_intensities), len(ion_intensities_none))
        # We should have the spot entry with its corresponding intensity value.
        self.assertEqual(len(ion_intensities.spot_ids), len(ion_intensities_none.spot_ids))
        self.assertEqual(len(ion_intensities.values), len(ion_intensities_none.values))
        # Reference value dataset inspection.
        max_value = numpy.nanmax(ion_intensities.values)
        max_value_none = numpy.nanmax(ion_intensities_none.values)
        self.assertEqual(max_value, max_value_none)

class TestClientMultipleRasters(ScilsLabTestCase):
    """
    A test class for the high level python Rest API.
    """

    @classmethod
    def setUpClass(cls):
        """
        Set up the client with a test file which contains more than one
        raster.
        """
        cls._temp_dataset = cls.temporaryDatasetFromArchive('cerebella.tar.gz')
        cls._session = LocalSession(filename=cls._temp_dataset.slx)
        cls._client = cls._session.dataset_proxy

    @classmethod
    def tearDownClass(cls):
        """ Terminate the open session """
        cls._session.close()
        cls._temp_dataset.cleanup()

    def test_get_ion_images(self):
        """ Test that we can retrieve the ion images """
        # Retrieve the images from the root region.
        ion_images = self._client.get_ion_images(
            min_mz=3351,
            max_mz=3359,
            region_id='Regions')
        # We should have two images image with as many intensity entries
        # as the rectangle area.
        self.assertEqual(len(ion_images), 2)
        for i in range(2):
            image = ion_images[i]
            self.assertSequenceEqual(
                (image.rectangle.height, image.rectangle.width),
                image.values.shape)
            self.assertEqual(
                (50.0, 50.0),
                image.spotsize) 

        # Test that different modes retrieve different ion image intensities.
        ion_image_sum = self._client.get_ion_images(
            min_mz=3351,
            max_mz=3359,
            region_id='Regions',
            mode='sum')[0]
        ion_image_mean = self._client.get_ion_images(
            min_mz=3351,
            max_mz=3359,
            region_id='Regions',
            mode='mean')[0]
        ion_image_max = self._client.get_ion_images(
            min_mz=3351,
            max_mz=3359,
            region_id='Regions',
            mode='max')[0]

        # Rectangle and transformation should be the same.
        # The intensities should differ significantly.
        for image in (ion_image_mean, ion_image_max):
            self.assertEqual(
                ion_image_sum.rectangle, image.rectangle)
            self.assertAlmostEqual(
                numpy.linalg.norm(
                    ion_image_sum.transformation - image.transformation), 0.0)

            ion_image_values_sum = numpy.nansum(ion_image_sum.values)
            image_values_sum = numpy.nansum(image.values)
            self.assertGreater(ion_image_values_sum, image_values_sum, 10.0)

        # Normalization can be specified by UUID or Name and gives same result
        for norm_uuid, norm_name in zip(
            [
                CerebellaUUIDs.median_norm,
                CerebellaUUIDs.tic_norm,
                CerebellaUUIDs.rms_norm
            ],
            [
                "Median", "Total Ion Count", "Root Mean Square"
            ]):

            ion_images_by_norm_uuid = self._client.get_ion_images(
                min_mz=3351,
                max_mz=3359,
                region_id='Regions',
                mode='mean',
                normalization_id=norm_uuid
            )

            ion_images_by_norm_name = self._client.get_ion_images(
                min_mz=3351,
                max_mz=3359,
                region_id='Regions',
                mode='mean',
                normalization_id=norm_name
            )

            for i in range(2):
                numpy.testing.assert_array_equal(
                    ion_images_by_norm_uuid[i].values,
                    ion_images_by_norm_name[i].values
                )

    def test_get_index_images(self):
        """ Test that we can retrieve the index images """
        # Retrieve the images from the root region
        index_images = self._client.get_index_images(
            region_id='Regions')
        # Retrieve also some ion images.
        ion_images = self._client.get_ion_images(
            min_mz=3351,
            max_mz=3359,
            region_id='Regions')

        # We should have one index image with an intensity entry per each
        # spot in the rectangle.
        self.assertEqual(len(index_images), 2)
        for i in range(2):
            image = ion_images[i]
            self.assertSequenceEqual(
                (image.rectangle.height, image.rectangle.width),
                image.values.shape)
            self.assertEqual(
                (50.0, 50.0),
                image.spotsize) 

        # Verify that we have multiple invalid spots labelled as -1 and only
        # one occurence of any other id>0.
        for ion_image, index_image in zip(ion_images, index_images):
            spot_ids = index_image.values
            self.assertEqual(numpy.min(spot_ids), -1)

            unique, counts = numpy.unique(spot_ids, return_counts=True)
            occurences = dict(zip(unique, counts))
            self.assertIn(-1, occurences.keys())
            self.assertGreater(occurences[-1], 1)
            del occurences[-1]
            for value in occurences.values():
                self.assertEqual(value, 1)

            # Check that the invalid spots correspond to an intensity of nan.
            numpy.testing.assert_allclose(numpy.isnan(ion_image.values), spot_ids == -1)


        # The image is split in 2 rasters of almost equal size.
        max_ids = sorted([
            numpy.max(index_images[0].values),
            numpy.max(index_images[1].values)])
        self.assertSequenceEqual(max_ids, [1131, 2335])

    def test_spots_raster(self):
        """ Test the raster index information in the spots dictionary """
        # Get all spots. There are two measurement rasters. The spots 0-1132
        # one should have raster index 0 and the others raster index 1.
        spots = self._client.get_region_spots('Regions')
        self.assertTrue(
            numpy.all(numpy.array(spots['raster'][:1132]) == 0))

        self.assertTrue(
            numpy.all(numpy.array(spots['raster'][1132:]) == 1))

        self.assertEqual(len(spots['raster']), 2336)

    def test_non_existing_region_or_normalization(self):
        """ Test that querying for a non-existing region raises """
        with self.assertRaisesRegex(ValueError, ".*does not exist.*"):
            self._client.get_region_spots("Foo")

        with self.assertRaisesRegex(ValueError, ".*does not exist.*"):
            self._client.get_spectrum(
                spot_id=0,
                normalization_id='Foo')

        with self.assertRaisesRegex(ValueError, ".*does not exist.*"):
            self._client.get_spectra_matrix(
                spot_ids=tuple(range(10)),
                normalization_id='Foo')

        with self.assertRaisesRegex(ValueError, ".*does not exist.*"):
            self._client.get_mean_spectrum(
                region_id='Foo',
                normalization_id=CerebellaUUIDs.tic_norm)

        with self.assertRaisesRegex(ValueError, ".*does not exist.*"):
            self._client.get_mean_spectrum(
                region_id=CerebellaUUIDs.region_measurement1,
                normalization_id='Foo')

        with self.assertRaisesRegex(ValueError, ".*does not exist.*"):
            self._client.get_region_attributes('Foo')

        with self.assertRaisesRegex(ValueError, ".*does not exist.*"):
            self._client.get_region_polygons('Foo')

        with self.assertRaisesRegex(ValueError, ".*does not exist.*"):
            self._client.get_ion_images(
                min_mz=3351,
                max_mz=3359,
                region_id='Foo',
                mode='sum',
                normalization_id=CerebellaUUIDs.tic_norm)

        with self.assertRaisesRegex(ValueError, ".*does not exist.*"):
            self._client.get_ion_images(
                min_mz=3351,
                max_mz=3359,
                region_id=CerebellaUUIDs.region_measurement1,
                mode='sum',
                normalization_id='Foo')

        with self.assertRaisesRegex(ValueError, ".*does not exist.*"):
            self._client.get_ion_intensities(
                min_mz=3351,
                max_mz=3359,
                region_id='Foo',
                mode='sum',
                normalization_id=CerebellaUUIDs.tic_norm)

        with self.assertRaisesRegex(ValueError, ".*does not exist.*"):
            self._client.get_ion_intensities(
                min_mz=3351,
                max_mz=3359,
                region_id=CerebellaUUIDs.region_measurement1,
                mode='sum',
                normalization_id='Foo')

        with self.assertRaisesRegex(ValueError, ".*does not exist.*"):
            self._client.get_index_images('Foo')


class TestSpotImageInterface(ScilsLabTestCase):
    """
    A test class for the spot image API.
    """

    @classmethod
    def setUpClass(cls):
        """
        Set up the client with a simple test file on the local host.
        """
        cls._temp_dataset = cls.temporaryDatasetFromArchive('cerebella.tar.gz')
        cls._session = LocalSession(filename=cls._temp_dataset.slx, timeout=90)
        cls._client = cls._session.dataset_proxy

    @classmethod
    def tearDownClass(cls):
        """ Terminate the open session """
        cls._session.close()
        cls._temp_dataset.cleanup()

    def _assert_sequence_almost_equal(self, seq1, seq2, delta):
        if len(seq1) != len(seq2):
            raise AssertionError("The sequences have different lengths")
        for s1, s2 in zip(seq1, seq2):
            if abs(s1 - s2) > delta:
                raise AssertionError("The difference in the values ", s1, s2, " is greater than delta")

    def _check_images_equivalent(self, image1, image2, values_delta = None):
        """ Check that two images are equivalent """
        self.assertTrue(isinstance(image1, type(image1)))
        self.assertEqual(image1.name, image2.name)
        self.assertEqual(image1.group_name, image2.group_name)
        self.assertSequenceEqual(tuple(image1.spot_ids), tuple(image2.spot_ids))
        if values_delta is None:
            self.assertSequenceEqual(tuple(image1.values), tuple(image2.values))
        else:
            self._assert_sequence_almost_equal(tuple(image1.values), tuple(image2.values), delta=values_delta)
        self.assertEqual(sorted(image1.user_info), sorted(image2.user_info))

    def test_basic_write_and_get_intensity_spot_image(self):
        """ Minimal functionality test for writing and getting spot image """
        ref_image = IntensitySpotImage(
            id="foo",
            name="Data",
            group_name="Goonies",
            spot_ids=tuple(range(200)),
            values=numpy.random.rand(200).astype(numpy.float32),
            user_info={"Year": "1985"}
        )
        image_id = self._client.write_intensity_spot_image(
            name=ref_image.name,
            group_name=ref_image.group_name,
            spot_ids=ref_image.spot_ids,
            values=ref_image.values,
            user_info=ref_image.user_info
        )
        # Retrieve the image we just saved.
        image = self._client.get_spot_image(image_id)
        self._check_images_equivalent(ref_image, image)
        # Try to write another image with different spots in the same group
        # and an exception will be raised.
        with self.assertRaises((ValueError, TypeError)):
            self._client.write_intensity_spot_image(
                name=ref_image.name,
                group_name=ref_image.group_name,
                spot_ids=[0, 1],
                values=[0., 0.],
                user_info=ref_image.user_info)

    def test_write_intensity_spot_image_values_spots_types(self):
        """ Test that we can write a spot image using different iterable types """
        spot_ids_args = [
            range(10),
            tuple(range(10)),
            numpy.array(range(10)),
            numpy.array(range(10), dtype=numpy.uint64)]
        values_args = [
            range(10),
            tuple(range(10)),
            tuple([float(x) for x in range(10)]),
            numpy.array(range(10), dtype=numpy.float32),
            numpy.array(range(10), dtype=numpy.int32)]

        for (spot_ids, values) in itertools.product(spot_ids_args, values_args):
            image_id = self._client.write_intensity_spot_image(
                name="Data",
                group_name="Goonies",
                spot_ids=spot_ids,
                values=values,
                user_info={"Year": "1985"})
            # Retrieve the image and check consistency.
            image = self._client.get_spot_image(image_id)
            self.assertSequenceEqual(tuple(image.spot_ids), tuple(range(10)))
            self.assertAlmostEqual(
                numpy.linalg.norm(image.values - numpy.array(range(10))), 0.0)

    def test_invalid_write_intensity_spot_image_args(self):
        """ Test that invalid arguments will raise an exception """
        valid_arguments = {
            'name': "Data",
            'group_name': "Goonies",
            'spot_ids': range(10),
            'values': range(10),
            'user_info': {"Year": "1985"}}

        invalid_arguments = (
            {'name': ""},
            {'name': 0},
            {'group_name': ""},
            {'group_name': 0},
            {'spot_ids': []},
            {'spot_ids': [-1, 1]},
            {'spot_ids': [2, 1, 0]},
            {'spot_ids': [0, 1], 'values': [10.0]},
            {'spot_ids':[0, 1], 'values':[numpy.finfo(numpy.float64).max, 10.0]},
            {'spot_ids': [0, 1], 'values': []})

        for args in invalid_arguments:
            with self.assertRaises((ValueError, TypeError)):
                kwargs = dict(valid_arguments)
                kwargs.update(args)
                self._client.write_intensity_spot_image(**kwargs)

    def test_get_spot_image_ids(self):
        """ Test the spot image ids getter """
        # Renew client and server, we need a clean file without existing
        # spot image.
        self.tearDownClass()
        self.setUpClass()

        # The test data contains already 3 normalization images, which
        # are treated internally as scalar spot images.
        norm_ids = self._client.get_spot_image_ids()
        self.assertEqual(len(norm_ids), 3)
        for image_id in norm_ids:
            image = self._client.get_spot_image(image_id)
            self.assertEqual(image.group_name, ('Normalizations'))

        # Create images with partially overlapping groups and names.
        ref_image_ids = []
        for name, group_name in [
            ('Bremen', 'DE'),
            ('Bremen', 'HB'),
            ('Hamburg', 'DE'),
            ('Berlin', 'DE')]:
            image_id = self._client.write_intensity_spot_image(
                name=name,
                group_name=group_name,
                spot_ids=[0, 1],
                values=[0., 3.])
            ref_image_ids.append(image_id)
        # All images.
        image_ids = self._client.get_spot_image_ids()
        self.assertSequenceEqual(
            sorted(ref_image_ids + norm_ids),
            sorted(image_ids))
        # Bremen only.
        image_ids = self._client.get_spot_image_ids(name="Bremen")
        self.assertSequenceEqual(
            sorted([ref_image_ids[i] for i in (0, 1)]),
            sorted(image_ids))
        # Bremen and DE
        image_ids = self._client.get_spot_image_ids(name="Bremen", group_name="DE")
        self.assertSequenceEqual(
            [ref_image_ids[0]],
            image_ids)
        # All DE.
        image_ids = self._client.get_spot_image_ids(group_name="DE")
        self.assertSequenceEqual(
            sorted([ref_image_ids[i] for i in (0, 2, 3)]),
            sorted(image_ids))

    def test_write_intensity_spot_image_utf8(self):
        """ Test that unicode strings can be saved in the user info """
        image_id = self._client.write_intensity_spot_image(
            name="foo",
            group_name="foo",
            spot_ids=[0, 1, 2, 3],
            values=[0., 1., 2., 3.],
            user_info={'Ψ\u03a8': '1\\/', 'ää': 'öö'})
        image = self._client.get_spot_image(image_id)
        self.assertEqual(
            sorted(image.user_info),
            sorted({'ΨΨ': '1\\/', 'ää': 'öö'})
        )

    def test_write_intensity_spot_image_slashes_in_keys(self):
        """ Test that forward slashes can be in user info keys """
        image_id = self._client.write_intensity_spot_image(
            name="foo",
            group_name="foo",
            spot_ids=[0, 1, 2, 3],
            values=[0., 1., 2., 3.],
            user_info={'a/a//a': 'foo', '/b:/b/': 'bar'})
        image = self._client.get_spot_image(image_id)
        self.assertEqual(
            sorted(image.user_info),
            sorted({'a/a//a': 'foo', '/b:/b/': 'bar'})
        )

    def test_print_spot_image_summary(self):
        """ Test that we can print a summary of available spot images """
        # Add some known image.
        self._client.write_intensity_spot_image(
            name="Mickey",
            group_name="Disney",
            spot_ids=[0, 1, 2, 3],
            values=[0., 1., 2., 3.])

        self._client.write_intensity_spot_image(
            name="Goofy",
            group_name="Disney",
            spot_ids=[0, 1, 2, 3],
            values=[0., 1., 2., 3.])

        contents = []
        contents.append("""
  Name: Goofy
  Group name: Disney""")
        contents.append("""
  Name: Mickey
  Group name: Disney""")
        contents.append("""
  Name: Median
  Group name: Normalizations""")
        contents.append("""
  Name: Root Mean Square
  Group name: Normalizations""")
        contents.append("""
  Name: Total Ion Count
  Group name: Normalizations""")
        with captureoutput() as (out, _):
            self._client.print_spot_image_summary()
            for content in contents:
                self.assertIn(content, out.getvalue())

    def test_basic_write_and_get_score_spot_image(self):
        """ Minimal functionality test for writing and getting score spot image """
        ref_image = ScoreSpotImage(
            id="foo",
            name="Paul",
            group_name="MyScoreImages",
            spot_ids=tuple(range(200)),
            values=numpy.random.rand(200).astype(numpy.float32),
            value_range=(10.0, 198.0),
            user_info={"Year": "1985"}
        )
        image_id = self._client.write_score_spot_image(
            name=ref_image.name,
            group_name=ref_image.group_name,
            spot_ids=ref_image.spot_ids,
            values=ref_image.values,
            value_range=ref_image.value_range,
            user_info=ref_image.user_info
        )
        my_values = [5.0, 6.0, 3.0, 9.0, 1.0]
        image_id2 = self._client.write_score_spot_image(
            name="foo2",
            group_name="MyScoreImages2",
            spot_ids=tuple(range(5)),
            values=my_values
        )
        # Retrieve the image we just saved.
        image = self._client.get_spot_image(image_id)
        self._check_images_equivalent(ref_image, image)

        # Retrieve second image and check the if value_range is set to min and max
        image2 = self._client.get_spot_image(image_id2)
        self.assertEqual(image2.value_range, (min(my_values), max(my_values)))

    def test_invalid_write_score_spot_image_args(self):
        """ Test that invalid arguments will raise an exception """
        valid_arguments = {
            'name': "Data",
            'group_name': "MyNewScores",
            'spot_ids': range(10),
            'values': range(10),
            'value_range': (100.0, 101.0),
            'user_info': {"Year": "1985"}}

        invalid_arguments = (
            {'name': ""},
            {'name': 0},
            {'group_name': ""},
            {'group_name': 0},
            {'spot_ids': []},
            {'spot_ids': [-1, 1]},
            {'spot_ids': [2, 1, 0]},
            {'spot_ids': [0, 1], 'values': [10.0]},
            {'spot_ids': [0, 1], 'values': []},
            {'spot_ids': [0, 1], 'values': [numpy.finfo(numpy.float64).max, 10.0]},
            {'value_range': (110.0, 100.0)},
            {'value_range': "foo"},
            {'value_range': 1})

        for args in invalid_arguments:
            with self.assertRaises((ValueError, TypeError)):
                kwargs = dict(valid_arguments)
                kwargs.update(args)
                self._client.write_score_spot_image(**kwargs)

    def test_basic_write_and_get_rgb_spot_image(self):
        """ Minimal functionality test for writing and getting rgb spot image """
        ref_image = RGBSpotImage(
            id="foo",
            name="Paul",
            group_name="MyRGBImages",
            spot_ids=tuple(range(3)),
            values=numpy.array(['#000064', '#64c800', '#140000']),
            user_info={"Year": "1985"}
        )
        image_id = self._client.write_rgb_spot_image(
            name=ref_image.name,
            group_name=ref_image.group_name,
            spot_ids=ref_image.spot_ids,
            values=ref_image.values,
            user_info=ref_image.user_info
        )

        # Retrieve the image we just saved.
        image = self._client.get_spot_image(image_id)
        self._check_images_equivalent(ref_image, image)

    def test_invalid_write_rgb_spot_image_args(self):
        """ Test that invalid arguments will raise an exception """
        valid_arguments = {
            'name': "Data",
            'group_name': "Goonies",
            'spot_ids': range(2),
            'values': ['#12aa34', '#23dd45'],
            'user_info': {"Year": "1985"}}

        invalid_arguments = (
            {'name': ""},
            {'name': 0},
            {'group_name': ""},
            {'group_name': 0},
            {'spot_ids': []},
            {'spot_ids': [-1, 1]},
            {'spot_ids': [2, 1, 0]},
            {'spot_ids': [0, 1], 'values': ['#1234az', '#1234cc']},
            {'spot_ids': [0, 1], 'values': ['', '#1234cc']},
            {'spot_ids': [0, 1], 'values': [[0, 300, 100], [0, 100, 0]]},
            {'spot_ids': [0, 1], 'values': [[0, 300, 100], [0, 100, 0]]},
            {'spot_ids': [0, 1], 'values': [[0, -23, 100], [0, 100, 0]]},
            {'spot_ids': [0, 1], 'values': [[0, 100], [0, 100, 0]]},
            {'spot_ids': [0, 1], 'values': [[0, 100, 150, 200], [0, 100, 0]]})

        for args in invalid_arguments:
            with self.assertRaises((ValueError, TypeError)):
                kwargs = dict(valid_arguments)
                kwargs.update(args)
                self._client.write_rgb_spot_image(**kwargs)

    def test_different_types_to_same_group(self):
        """ Check that adding different image types to the same group is forbidden """
        self._client.write_intensity_spot_image(
            name="foo",
            group_name="Foo",
            spot_ids=[0, 1],
            values=[0., 0.])

        with self.assertRaisesRegex(
                ValueError,
                ".*The group already contains spot images which are not compatible with the current image.*"):
            self._client.write_score_spot_image(
                name="foo",
                group_name="Foo",
                spot_ids=[0, 1],
                values=[0., 0.],
                value_range=[100.0, 101.0])

        with self.assertRaisesRegex(
                ValueError,
                ".*The group already contains spot images which are not compatible with the current image.*"):
            self._client.write_score_spot_image(
                name="foo",
                group_name="Foo",
                spot_ids=[0, 1],
                values=[0., 0.],
                value_range=[100.0, 101.0])

        with self.assertRaisesRegex(
                ValueError,
                ".*The group already contains spot images which are not compatible with the current image.*"):
            self._client.write_rgb_spot_image(
                name="foo",
                group_name="Foo",
                spot_ids=[0, 1],
                values=[[0, 0, 100], [150, 100, 0]])

    def test_spot_image_metainformation_is_written(self):
        """ Test that the image is correctly retrieved after closing session """
        temp_dataset = self.temporaryDatasetFromArchive('cerebella.tar.gz')
        with LocalSession(filename=temp_dataset.slx, retries=0, port=8090) as session:
            client = session.dataset_proxy

            scalar_image = IntensitySpotImage(
                id="foo",
                name="Data",
                group_name="Goonies_test_meta",
                spot_ids=tuple(range(200)),
                values=numpy.random.rand(200).astype(numpy.float32),
                user_info={"Year": "1985"}
            )
            scalar_image_id = client.write_intensity_spot_image(
                name=scalar_image.name,
                group_name=scalar_image.group_name,
                spot_ids=scalar_image.spot_ids,
                values=scalar_image.values,
                user_info=scalar_image.user_info
            )
            score_image = ScoreSpotImage(
                id="foo",
                name="Paul",
                group_name="MyScoreImages_test_meta",
                spot_ids=tuple(range(200)),
                values=numpy.random.rand(200).astype(numpy.float32),
                value_range=(10.0, 198.0),
                user_info={"Year": "1985"}
            )
            score_image_id = client.write_score_spot_image(
                name=score_image.name,
                group_name=score_image.group_name,
                spot_ids=score_image.spot_ids,
                values=score_image.values,
                value_range=score_image.value_range,
                user_info=score_image.user_info
            )
            rgb_image = RGBSpotImage(
                id="foo",
                name="Paul",
                group_name="MyRGBImages_test_meta",
                spot_ids=tuple(range(3)),
                values=['#1122ff', '#33ff10', '#34dd00'],
                user_info={"Year": "1985"}
            )
            rgb_image_id = client.write_rgb_spot_image(
                name=rgb_image.name,
                group_name=rgb_image.group_name,
                spot_ids=rgb_image.spot_ids,
                values=rgb_image.values,
                user_info=rgb_image.user_info
            )

        # Open a new session and retrieve the images. If the metainformation
        # is not correctly flushed, the test will fail.
        with LocalSession(filename=temp_dataset.slx, retries=0, port=8090) as session:
            client = session.dataset_proxy

            for image, image_id in [
                    (scalar_image, scalar_image_id),
                    (score_image, score_image_id),
                    (rgb_image, rgb_image_id)]:
                self._check_images_equivalent(
                    image,
                    client.get_spot_image(image_id))

        temp_dataset.cleanup()

    def test_float_double_conversion_spot_image(self):
        """ Checks if the conversion of the values from double to
         float and vice-versa works as excepted"""
        ref_image = IntensitySpotImage(
            id="foo",
            name="Paul",
            group_name="MyIntensityImages",
            spot_ids=tuple(range(100)),
            values=numpy.random.rand(100),
            user_info={"Year": "1985"}
        )
        image_id = self._client.write_intensity_spot_image(
            name=ref_image.name,
            group_name=ref_image.group_name,
            spot_ids=ref_image.spot_ids,
            values=ref_image.values,
            user_info=ref_image.user_info
        )

        # Retrieve the image we just saved.
        image = self._client.get_spot_image(image_id)
        self._check_images_equivalent(ref_image, image, values_delta=10e-6)

    def test_write_normalization(self):

        spot_ids = self._client.get_region_spots('Regions')['spot_id']
        spectra_matrix = self._client.get_spectra_matrix(spot_ids)

        max_norm_vals = numpy.max(spectra_matrix.intensities, 1)

        norm_id_unscaled = self._client.write_normalization("my_norm", max_norm_vals)

        normalized_spectra_matrix_unscaled = self._client.get_spectra_matrix(spot_ids, norm_id_unscaled)

        normalized_maxima_unscaled = numpy.max(normalized_spectra_matrix_unscaled.intensities, 1)

        expected_unscaled = numpy.ones_like(max_norm_vals)
        numpy.testing.assert_allclose(expected_unscaled, normalized_maxima_unscaled)

        norm_spot_image_unscaled = self._client.get_spot_image(norm_id_unscaled)
        numpy.testing.assert_allclose(norm_spot_image_unscaled.values, max_norm_vals)
        self.assertEqual( norm_spot_image_unscaled.group_name, "Normalizations")
        self.assertEqual( norm_spot_image_unscaled.name, "my_norm")

        norm_id_scaled = self._client.write_normalization("my_norm_scaled", max_norm_vals, scale_to_average= True)
        normalized_spectra_matrix_scaled = self._client.get_spectra_matrix(spot_ids, norm_id_scaled)
        normalized_maxima_scaled = numpy.max(normalized_spectra_matrix_scaled.intensities, 1)
        expected_scaled = numpy.ones_like(max_norm_vals) * numpy.mean(max_norm_vals)
        numpy.testing.assert_allclose(expected_scaled, normalized_maxima_scaled, rtol = 5e-6)

        norm_spot_image_scaled = self._client.get_spot_image(norm_id_scaled)
        numpy.testing.assert_allclose(
            norm_spot_image_scaled.values,
            max_norm_vals / numpy.mean(max_norm_vals),
            rtol = 5e-6)

        self.assertEqual( norm_spot_image_unscaled.group_name, "Normalizations")
        self.assertEqual( norm_spot_image_unscaled.name, "my_norm")
        self.assertEqual( norm_spot_image_scaled.name, "my_norm_scaled")

        all_spot_images = self._client.get_spot_image_ids()
        self.assertIn( norm_id_unscaled, all_spot_images)
        self.assertIn( norm_id_scaled, all_spot_images)

        all_normalizations = self._client.get_normalizations()
        self.assertIn( norm_id_unscaled, all_normalizations)
        self.assertIn( norm_id_scaled, all_normalizations)

        with self.assertRaisesRegex(
            ValueError,
            "No mean spectrum for normalization"):
            self._client.get_mean_spectrum('Regions', norm_id_scaled)

    def test_write_normalization_with_invalid_parameters(self):

        spot_ids = self._client.get_region_spots('Regions')['spot_id']
        spectra_matrix = self._client.get_spectra_matrix(spot_ids)

        # wrong number of normalization values
        with self.assertRaisesRegex(
            ValueError,
            "The number of normalization values doesn't match the number of spots"):
            self._client.write_normalization('mynorm', numpy.ones( len(spot_ids) - 1, dtype=numpy.float64))

        # pre-existing normalization
        with self.assertRaisesRegex(
            ValueError,
            "A normalization with name 'Total Ion Count' already exists"):
            self._client.write_normalization('Total Ion Count', numpy.ones_like( spot_ids, dtype=numpy.float64))

        # non-finite values in normalization values
        non_finite_norm = numpy.ones_like(spot_ids, dtype=numpy.float64)
        non_finite_norm[0] = numpy.nan 
        with self.assertRaisesRegex(
            ValueError,
            "Cannot write normalization: values array contains non-finite values"):
            self._client.write_normalization('mynorm', non_finite_norm)

        # zero as normalization value
        zero_norm = numpy.ones_like(spot_ids, dtype=numpy.float64)
        zero_norm[0] = 0.0
        with self.assertRaisesRegex(
            ValueError,
            "Normalization contains values smaller or equal to 0"):
            self._client.write_normalization('mynorm', zero_norm)

        # negative normalization value
        negative_norm = numpy.ones_like(spot_ids, dtype=numpy.float64)
        negative_norm[0] = -1.0
        with self.assertRaisesRegex(
            ValueError,
            "Normalization contains values smaller or equal to 0"):
            self._client.write_normalization('mynorm', negative_norm)

        # empty normalization name
        with self.assertRaisesRegex(
            ValueError,
            "No name for the normalization was provided"):
            self._client.write_normalization('', numpy.ones_like(spot_ids, dtype=numpy.float64))

    def test_normalization_uuid_exists_as_normalization_name(self):
        """
        Test that if a normalization has a name that is equal to a UUID of
        another normalization, the UUID takes precedence
        """

        spot_ids = self._client.get_region_spots('Regions')['spot_id']
        spectra_matrix = self._client.get_spectra_matrix(spot_ids)

        max_norm_vals = numpy.max(spectra_matrix.intensities, 1)

        spectrum_tic = self._client.get_spectrum(9, CerebellaUUIDs.tic_norm)
        mean_spectrum_tic = self._client.get_mean_spectrum(
            'Regions', CerebellaUUIDs.tic_norm)
        
        feature_tic = self._client.feature_table.get_feature_intensities(
            0, 'Regions', 'area', CerebellaUUIDs.tic_norm )
        
        ion_images_tic = self._client.get_ion_images(
            min_mz=3351,
            max_mz=3359,
            region_id='Regions',
            normalization_id=CerebellaUUIDs.tic_norm)

        ion_intensities_tic = self._client.get_ion_intensities(
            min_mz=3351,
            max_mz=3359,
            region_id='Regions',
            normalization_id=CerebellaUUIDs.tic_norm)
        
        spectra_matrix_tic = self._client.get_spectra_matrix(
            list(range(9)), normalization_id=CerebellaUUIDs.tic_norm
        )

        norm_with_name_of_existing_uuid = self._client.write_normalization(
            CerebellaUUIDs.tic_norm, max_norm_vals)
        
        spectrum = self._client.get_spectrum(9, CerebellaUUIDs.tic_norm)

        numpy.testing.assert_array_equal(
            spectrum_tic['intensities'],
            spectrum['intensities']
        )

        mean_spectrum = self._client.get_mean_spectrum(
            'Regions', CerebellaUUIDs.tic_norm)
        
        numpy.testing.assert_array_equal(
            mean_spectrum_tic['intensities'],
            mean_spectrum['intensities']
        )
        
        feature = self._client.feature_table.get_feature_intensities(
            0, 'Regions', 'area', CerebellaUUIDs.tic_norm )
        
        numpy.testing.assert_array_equal(
            feature_tic.values,
            feature.values
        )
        
        ion_images = self._client.get_ion_images(
            min_mz=3351,
            max_mz=3359,
            region_id='Regions',
            normalization_id=CerebellaUUIDs.tic_norm)
        
        numpy.testing.assert_array_equal(
            ion_images_tic[0].values,
            ion_images[0].values
        )

        ion_intensities = self._client.get_ion_intensities(
            min_mz=3351,
            max_mz=3359,
            region_id='Regions',
            normalization_id=CerebellaUUIDs.tic_norm)
        
        numpy.testing.assert_array_equal(
            ion_intensities_tic.values,
            ion_intensities.values
        )
        
        spectra_matrix = self._client.get_spectra_matrix(
            list(range(9)), normalization_id=CerebellaUUIDs.tic_norm
        ) 

        numpy.testing.assert_array_equal(
            spectra_matrix_tic.intensities,
            spectra_matrix.intensities
        )


@unittest.skip("This test is very slow")
class TestTightLoop(ScilsLabTestCase):
    """
    A test class for the high level python Rest API.
    """

    @classmethod
    def setUp(self):
        """
        Set up the client with a simple test file on the local host.
        """
        self._temp_dataset = self.temporaryDatasetFromArchive('cerebella.tar.gz')

    @classmethod
    def tearDownClass(self):
        """ Terminate the open session """
        self._temp_dataset.cleanup()

    def test_tight_loop(self):
        """ Tests that no connection errors happen in tight loops"""

        with LocalSession( self._temp_dataset.slx) as session:
            dataset = session.dataset_proxy

            n_requests = 0
            for i in range(20000):
                version = dataset.get_server_version()
                n_requests += 1

        self.assertEqual(n_requests, 20000)




  
if __name__ == '__main__':
    unittest.main()
