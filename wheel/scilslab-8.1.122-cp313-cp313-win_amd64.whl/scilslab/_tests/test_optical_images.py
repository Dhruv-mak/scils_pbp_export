#
# This file is part of the SCiLS Lab Python API client (scilslab).
#
# Copyright (C) 2020 - 2025, Bruker Daltonics GmbH & Co. KG, Bremen, Germany
# Contact: support.scils@bruker.com
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; version 2.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.
# If not, see <http://www.gnu.org/licenses/gpl-2.0.html>.
# SPDX-License-Identifier: GPL-2.0-only
#
# In addition to GPL2, this program can be provided by Bruker Daltonics
# under alternative licensing models. For more information on
# alternative options, please contact support.scils@bruker.com.
#
import hashlib
import pathlib
from typing import OrderedDict
import unittest
from unittest.mock import patch

import numpy
import pandas as pd 

from scilslab.session import LocalSession
from scilslab._tests.utils import CerebellaUUIDs
from scilslab._tests.utils import ScilsLabTestCase

class TestOpticalImageInterface(ScilsLabTestCase):
    """
    A test class for the optical image API
    """
    def setUp(self):
        """
        Set up the client with a simple test file on the local host.
        """
        self._temp_dataset = self.temporaryDatasetFromArchive('cerebella.tar.gz')
        self._session = LocalSession(filename=self._temp_dataset.slx, timeout=90)
        self._client = self._session.dataset_proxy

    def tearDown(self):
        """ Terminate the open session """
        self._session.close()
        self._temp_dataset.cleanup()


    def test_get_optical_image_ids(self):

        expected_bitmap_table = OrderedDict()
        expected_bitmap_table['id'] = [
            CerebellaUUIDs.overview_image,
            CerebellaUUIDs.image_cerebellum_part1,
            CerebellaUUIDs.image_cerebellum_part2,
            CerebellaUUIDs.image_external_multires ]
        expected_bitmap_table['name'] = ["Overview Image", "cerebellum_part1", "cerebellum_part2", "scl-2402cer-multires"]
        expected_bitmap_table['type'] = ["PNG", "png", "png", "PNG"]
        expected_bitmap_table['date'] = ["24-02-08 11:13:59", "24-02-08 11:13:59", "24-02-08 11:13:59", "24-03-05 06:20:53"]
        expected_bitmap_table['has_external_image'] = [False, False, False, True]
        expected_bitmap_table = pd.DataFrame(expected_bitmap_table)
        expected_bitmap_table.sort_values(by='id', inplace=True, ignore_index=True) 

        optical_image_table = self._client.optical_images.get_ids()
        optical_image_table.sort_values( by='id', inplace=True, ignore_index=True)

        pd.testing.assert_frame_equal(optical_image_table, expected_bitmap_table, check_like = True)

    def test_get_optical_image(self):
        expected_world2px = numpy.array(
            [ 
                [1.98607487e-02,  2.35598374e-03,  0.00000000e+00, -2.15678296e+00],
                [2.35598374e-03, -1.98607487e-02,  0.00000000e+00,  3.86979357e+01],
                [0.00000000e+00,  0.00000000e+00,  1.00000000e+00,  0.00000000e+00],
                [0.00000000e+00,  0.00000000e+00,  0.00000000e+00,  1.00000000e+00]
            ])

        expected_px2world = numpy.linalg.inv( expected_world2px )

        bitmap = self._client.optical_images.get_image(CerebellaUUIDs.image_cerebellum_part1, lightweight = False)
        self.assertEqual( bitmap.name, "cerebellum_part1")
        self.assertEqual( bitmap.type, "png" )
        numpy.testing.assert_allclose( bitmap.px2world, expected_px2world)
        self.assertEqual( 
            hashlib.md5( bitmap.data ).hexdigest(),
            'b2138ac07f35e925dd73956b66744e7e'
        )
        self.assertListEqual( bitmap.spots, [*range(1132)]  )
        self.assertIsNone( bitmap.external_image)
        

    def test_get_optical_image_lightweight(self):
        expected_world2px = numpy.array(
            [ 
                [1.98607487e-02,  2.35598374e-03,  0.00000000e+00, -2.15678296e+00],
                [2.35598374e-03, -1.98607487e-02,  0.00000000e+00,  3.86979357e+01],
                [0.00000000e+00,  0.00000000e+00,  1.00000000e+00,  0.00000000e+00],
                [0.00000000e+00,  0.00000000e+00,  0.00000000e+00,  1.00000000e+00]
            ])

        expected_px2world = numpy.linalg.inv( expected_world2px )

        bitmap = self._client.optical_images.get_image(CerebellaUUIDs.image_cerebellum_part1, lightweight = True)
        self.assertEqual( bitmap.name, "cerebellum_part1")
        self.assertEqual( bitmap.type, "png" )
        numpy.testing.assert_allclose( bitmap.px2world, expected_px2world)
        self.assertEqual( bitmap.data, bytes())
        self.assertListEqual( bitmap.spots, [*range(1132)]  )
        self.assertIsNone( bitmap.external_image)

    def test_get_image_with_external_reference(self):

        bitmap = self._client.optical_images.get_image(CerebellaUUIDs.image_external_multires)
        self.assertEqual( bitmap.name, "scl-2402cer-multires")
        self.assertEqual( bitmap.type, "PNG" )
        self.assertNotEqual( bitmap.data, bytes())
        self.assertListEqual( bitmap.spots, [*range(1132, 2336)]  )

        self.assertEqual( bitmap.external_image.path, R"C:\data\scl-2402cer-multires.tiff" )

        expected_external_world2px = numpy.array([
            [ 2.53386733e+00, -1.62181745e-01,  0.00000000e+00, 2.88631282e+03],
            [-1.62181745e-01, -2.53386733e+00,  0.00000000e+00, 2.26791857e+03],
            [ 0.00000000e+00,  0.00000000e+00,  1.00000000e+00, 0.00000000e+00],
            [ 0.00000000e+00,  0.00000000e+00,  0.00000000e+00, 1.00000000e+00]]
        )
        
        numpy.testing.assert_allclose( bitmap.external_image.px2world, expected_external_world2px )
        self.assertEqual(
            bitmap.external_image.metadata,
            dict({'hash': '7e5afc64cc740ffde3156d2a3716022518a21359a2c89bc0516ae157963b285e',
                  'height': '826',
                  'type': 'tiff',
                  'width': '904'})
            )


    def test_write_optical_image_binary(self):

        px2world = numpy.array(
            [ 
                [1.98607487e-02,  2.35598374e-03,  0.00000000e+00, -2.15678296e+00],
                [2.35598374e-03, -1.98607487e-02,  0.00000000e+00,  3.86979357e+01],
                [0.00000000e+00,  0.00000000e+00,  1.00000000e+00,  0.00000000e+00],
                [0.00000000e+00,  0.00000000e+00,  0.00000000e+00,  1.00000000e+00]
            ])

        data = b"imagedata\x00withnull\xff\x23andvaluesgreater128"

        new_image_id = self._client.optical_images.write_image(
            data,
            px2world,
            CerebellaUUIDs.image_cerebellum_part2,
            "newimage",
            "jpg"  
        )

        regex = "^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$"
        self.assertRegex(new_image_id, regex)

        backread_image = self._client.optical_images.get_image( new_image_id )
        self.assertEqual( backread_image.name, "newimage")
        self.assertEqual( backread_image.type, "jpg" )
        numpy.testing.assert_allclose( backread_image.px2world, px2world)
        self.assertListEqual( backread_image.spots, [*range(1132, 2336)]  )
        self.assertEqual( backread_image.data, data)

        bitmap_table = self._client.optical_images.get_ids()
        self.assertEqual( bitmap_table.shape[0], 5)
        new_row = bitmap_table[bitmap_table['id'] == new_image_id]
        new_row.reset_index(drop=True, inplace=True)
        self.assertEqual(new_row['name'][0], "newimage")
        self.assertEqual(new_row['type'][0], "jpg")

    def test_write_optical_image_from_file(self):

        input_file = pathlib.Path(self._temp_dataset.directory_name, "testfile.JPG")
        input_file.write_bytes(b"imagedata\x00withnull\xff\x23andvaluesgreater128")

        px2world = numpy.array(
            [ 
                [1.98607487e-02,  2.35598374e-03,  0.00000000e+00, -2.15678296e+00],
                [2.35598374e-03, -1.98607487e-02,  0.00000000e+00,  3.86979357e+01],
                [0.00000000e+00,  0.00000000e+00,  1.00000000e+00,  0.00000000e+00],
                [0.00000000e+00,  0.00000000e+00,  0.00000000e+00,  1.00000000e+00]
            ])

        new_image_id = self._client.optical_images.write_image(
            str(input_file),
            px2world
        )

        regex = "^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$"
        self.assertRegex(new_image_id, regex)

        backread_image = self._client.optical_images.get_image( new_image_id )
        self.assertEqual( backread_image.name, "testfile")
        self.assertEqual( backread_image.type, ".JPG" )
        numpy.testing.assert_allclose( backread_image.px2world, px2world)
        self.assertListEqual( backread_image.spots, [*range(2336)]  )
        self.assertEqual( backread_image.data, b"imagedata\x00withnull\xff\x23andvaluesgreater128")

        bitmap_table = self._client.optical_images.get_ids()
        self.assertEqual( bitmap_table.shape[0], 5)
        new_row = bitmap_table[bitmap_table['id'] == new_image_id]
        new_row.reset_index(drop=True, inplace=True)
        self.assertEqual(new_row['name'][0], "testfile")
        self.assertEqual(new_row['type'][0], ".JPG")

    def test_write_optical_image_invalid_inputs(self):

        world2px = numpy.array(
            [ 
                [1.98607487e-02,  2.35598374e-03,  0.00000000e+00, -2.15678296e+00],
                [2.35598374e-03, -1.98607487e-02,  0.00000000e+00,  3.86979357e+01],
                [0.00000000e+00,  0.00000000e+00,  1.00000000e+00,  0.00000000e+00],
                [0.00000000e+00,  0.00000000e+00,  0.00000000e+00,  1.00000000e+00]
            ])
        
        data = b"imagedata\x00withnull\xff\x23andvaluesgreater128"

        with self.assertRaisesRegex(
                ValueError, 'The request for write_image failed with error message: Attempt to write invalid optical image failed: Invalid type was provided'
                ):
            self._client.optical_images.write_image(data, world2px, 'e41c7cf7-92fd-4f5e-a424-d288a370d3f7', "foo", "bar")

        with self.assertRaisesRegex(
                ValueError, "The request for write_image failed with error message: Could not retrieve reference image. Was a valid identifier provided?"
                ):
            self._client.optical_images.write_image(data, world2px, 'invalid', "foo", "jpg")

        with self.assertRaisesRegex(
                ValueError, "'px2world' has incorrect format: Must be an iterable with 16 elements"
                ):
            self._client.optical_images.write_image(data, [1,2,3,4,5], 'e41c7cf7-92fd-4f5e-a424-d288a370d3f7', "foo", "jpg")

        with self.assertRaisesRegex(
                ValueError, "The request for write_image failed with error message: Attempt to write invalid optical image failed: No binary data was provided"
                ):
            self._client.optical_images.write_image(bytes(), world2px, 'e41c7cf7-92fd-4f5e-a424-d288a370d3f7', "foo", "jpg")

        with self.assertRaisesRegex(
                ValueError, "If data is of type bytes, a name must be specified"
                ):
            self._client.optical_images.write_image(bytes(), world2px, 'e41c7cf7-92fd-4f5e-a424-d288a370d3f7')

        with self.assertRaisesRegex(
                ValueError, "If data is of type bytes, an image_type must be specified"
                ):
            self._client.optical_images.write_image(bytes(), world2px, 'e41c7cf7-92fd-4f5e-a424-d288a370d3f7', "foo")

        with self.assertRaisesRegex(
                ValueError, "The file 'thisisastring' specified by 'data' does not exist."
                ):
            self._client.optical_images.write_image("thisisastring", world2px, 'e41c7cf7-92fd-4f5e-a424-d288a370d3f7', "foo", "jpg")

        with self.assertRaisesRegex(
                ValueError, "Data is neither a bytes object nor can it be interpreted as path."
                ):
            self._client.optical_images.write_image([1,2,3], world2px, 'e41c7cf7-92fd-4f5e-a424-d288a370d3f7', "foo", "jpg")

        input_file_without_extension = pathlib.Path(self._temp_dataset.directory_name, "testfile")
        input_file_without_extension.write_bytes(b"imagedata\x00withnull\xff\x23andvaluesgreater128")

        with self.assertRaisesRegex(
                ValueError, r"The specified file .* has no extension."
                ):
            self._client.optical_images.write_image(input_file_without_extension, world2px, 'e41c7cf7-92fd-4f5e-a424-d288a370d3f7')


if __name__ == '__main__':
    unittest.main()
