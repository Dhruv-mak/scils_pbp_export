__version__ = "8.1.122"
_scilslib = "59.0.12481"
_commit = "432b5ca0a7688bfd60638a6502fbbe29f7693d1d"
