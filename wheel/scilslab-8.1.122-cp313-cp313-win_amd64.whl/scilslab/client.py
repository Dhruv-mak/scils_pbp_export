#
# This file is part of the SCiLS Lab Python API client (scilslab).
#
# Copyright (C) 2020 - 2025, Bruker Daltonics GmbH & Co. KG, Bremen, Germany
# Contact: support.scils@bruker.com
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; version 2.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.
# If not, see <http://www.gnu.org/licenses/gpl-2.0.html>.
# SPDX-License-Identifier: GPL-2.0-only
#
# In addition to GPL2, this program can be provided by Bruker Daltonics
# under alternative licensing models. For more information on
# alternative options, please contact support.scils@bruker.com.
#
"""
This module contains the Client tools for the SCiLSLab rest API.
"""

import pathlib
from textwrap import indent
import warnings

import numpy
import pandas as pd
import warnings

from scilslab import _cppserialization

from scilslab._connection import _Connection
from scilslab.feature_table import FeatureTableProxy
from scilslab.optical_images import OpticalImageProxy
from scilslab.types import RegionTree
from scilslab.types import _check_interval_parameters

class DatasetProxy:
    """A proxy class to interact with the dataset

    The DatasetProxy class containing the methods to get and write information
    from and to a data set provided by a server. A server can be started
    locally with the utility class :obj:`scilslab.LocalSession`.
    """
    client_version = _cppserialization.apiVersionString()
    """string: A string identifying the API version used by the client
    """

    def __init__(
            self,
            authentication_token,
            hostname="127.0.0.1",
            port=8086,
            retries=2,
            sleep=0.1,
            tls=False,
            verify=True):
        """
        Create a dataset proxy and connect to a SCiLSLab server.

        Args:
            authentication_token (str): an authentication token required by the
                server to enable connection. The server issues a bearer
                authentication token at startup and accepts connection only
                from clients providing this bearer token.
            address (str): the server hostname or ip address.
            port (int): the port to connect to.
            retries (int): number of retries when a request fails and no
                response was received by the server. Set to 0 to disable,
                set to 1 or larger to circumvent idle connection issues.
            sleep (float): sleep time between retries in seconds.
            tls (bool): Specifies if this is a tls secured connection. Defaults
                to false.
            verify: Either a boolean, in which case it controls whether
                the server's TLS certificate is verified, or a string, in which
                case it must be a path to a CA bundle to use. Has no effect if
                tls is false. Defaults to True.
        """
        self.authentication_token = authentication_token
        self.hostname = hostname
        self.port = port
        self.retries = retries
        self.sleep = sleep
        self.tls = tls
        self.verify = verify

        self._connection = _Connection(
            self.authentication_token,
            self.hostname,
            self.port,
            self.retries,
            self.sleep,
            self.tls,
            self.verify)

        self._feature_list_proxy = FeatureTableProxy(self._connection)
        self._optical_image_proxy = OpticalImageProxy(self._connection)


    @property
    def feature_table(self):
        """ :obj:`FeatureTableProxy`: A proxy object to interact with the feature table of the data set.
        """
        return self._feature_list_proxy

    @property
    def optical_images(self):
        """ :obj:`OpticalImageProxy`: A proxy object to interact with optical images in the data set.
        """
        return self._optical_image_proxy

    def get_server_version(self):
        """
        Query the server API version

        Returns:
            :obj:`string`: The string with the API version utilized by the server.
        """
        response = self._connection.get("version")
        return response.text

    def get_license_info(self):
        """
        Query the license used by the server

        Returns:
            :obj:`string`: Information about the license used to start the Server.
        """
        response = self._connection.get("licenseinfo")
        return response.text

    def get_file_info(self):
        """
        Query file name and uuid of the data set

        Returns:
            :obj:`FileInfo`: Information about the file path and the uuid of the dataset.
        """
        response = self._connection.get("fileinfo")

        return _cppserialization.deserializeFileInfo(response.content)

    def get_ion_images(self, min_mz, max_mz, region_id=None, mode=None, normalization_id=None):
        """
        Retrieve ion images

        Args:
            min_mz (float): The lower mass bound.
            max_mz (float): The upper mass bound.
            region_id (string): The identifier of the region.
                Default region_id is set to 'Regions'
            mode (string): The interval processing mode. Supported modes are
                'area', 'mean', 'max' and 'sum'. Default mode is set to 'area'
            normalization_id (string): The uuid or the name of the normalization to be used.
                Empty string or None (default) will return the non-normalized ion images. If the
                same string is both a valid uuid and a name, it is interpreted as uuid.
                For the available normalizations, see :func:`DatasetProxy.get_normalizations`.

        Returns:
            list of :obj:`Image`: A list of images, one per each
            intersection between measurement raster and queried region.
            The intensity of images represent the intensity of the spectra.
        """
        if mode is None:
            mode = 'area'
        if normalization_id is None:
            normalization_id = ''
        if region_id is None:
            region_id = 'Regions'

        params = {
            'regionid': region_id,
            'min': min_mz,
            'max': max_mz,
            'mode': mode,
            'normid': normalization_id
        }

        response = self._connection.get("region/ionimage", params=params)
        return _cppserialization.deserializeIonImages(response.content, region_id)


    def get_ion_intensities(self, min_mz, max_mz, region_id=None, mode=None, normalization_id=None):
        """
        Retrieve ion intensities

        Args:
            min_mz (float): The lower mass bound.
            max_mz (float): The upper mass bound.
            region_id (str): The identifier of the region.
                Default region_id is set to 'Regions'
            mode (string): The interval processing mode. Supported modes are
                'area', 'mean', 'max' and 'sum'. Default mode is set to 'area'.
            normalization_id (string): The uuid or the name of the normalization to be used.
                Empty string or None (default) will return the non-normalized intensities. If the
                same string is both a valid uuid and a name, it is interpreted as uuid.
                For the available normalizations, see :func:`DatasetProxy.get_normalizations`.

        Returns:
            :obj:`IonIntensities`: Contains the spot_ids and their
            corresponding intensity values.
        """
        if mode is None:
            mode = 'area'
        if normalization_id is None:
            normalization_id = ''
        if region_id is None:
            region_id = 'Regions'

        params = {
            'regionid': region_id,
            'min': min_mz,
            'max': max_mz,
            'mode': mode,
            'normid': normalization_id
        }

        response = self._connection.get("region/ionintensities", params=params)

        return _cppserialization.deserializeIonIntensities(response.content, region_id)

    def get_index_images(self, region_id = None):
        """
        Retrieve index images for a region

        Args:
            region_id (string): the identifier of the region.

        Returns:
            list of :obj:`Image`: a list of images, one per each
            intersection between measurement raster and queried region.
            The intensity of images in each spot represent the spot index
            each. Non-existing spots are identified by the value -1.
        """
        if region_id is None:
            region_id = 'Regions'

        params = {'regionid': region_id}
        response = self._connection.get('region/indeximage', params=params)
        
        return _cppserialization.deserializeIndexImages(response.content, region_id)
    

    def get_normalizations(self):
        """
        Query available normalizations

        Returns:
            dict: the normalizations dictionary where the keys are unique
            ids and the values descriptive names. The order of the items is
            unpredictable.
        """
        response = self._connection.get("normalizations")

        return _cppserialization.deserializeNormalizations(response.content)

    def get_spectrum(self, spot_id, normalization_id=None, rebinned=False):
        """
        Retrieve a spectrum

        Args:
            spot_id (int): The identifier of the spot.
            normalization_id (string): The uuid or the name of the normalization to be used.
                Empty string or None (default) will return the non-normalized spectrum. If the
                same string is both a valid uuid and a name, it is interpreted as uuid.
                For the available normalizations, see :func:`DatasetProxy.get_normalizations`.
            rebinned (bool): indicates if the raw or the rebinned spectrum should be returned.
                By default it is false.

        Returns:
            A dictionary with the intensities and m/z values of the
            queried spectra: `{'intensities': numpy.array of floats, 'mz': numpy.array of floats}`
        """
        if normalization_id is None:
            normalization_id = ''

        params = {
            'spotid': spot_id,
            'normid': normalization_id,
            'rebinned': rebinned
        }
        response = self._connection.get('spectrum', params=params)

        return _cppserialization.deserializeSpectrum(response.content)

    def get_mean_spectrum(self, region_id=None, normalization_id=None):
        """
        Retrieve a mean spectrum for a region

        Args:
            region_id (string): the identifier of the region.
            normalization_id (string): The uuid or the name of the normalization to be used.
                Empty string or None (default) will return the non-normalized spectrum. If the
                same string is both a valid uuid and a name, it is interpreted as uuid.
                For the available normalizations, see :func:`DatasetProxy.get_normalizations`.

        Returns:
            A dictionary with the intensities and m/z values of the
            queried spectra: `{'intensities': numpy.array of floats, 'mz': numpy.array of floats}`
        """
        if region_id is None:
            region_id = 'Regions'
        if normalization_id is None:
            normalization_id = ''

        params = {
            'regionid': region_id,
            'normid': normalization_id
        }

        response = self._connection.get('region/mean', params = params)
        return _cppserialization.deserializeSpectrum(response.content)

    def get_region_spots(self, region_id):
        """
        Retrieve the spots for a region

        Args:
            region_id (str): the identifier of the region.

        Returns:
            A dictionary containing the spots identifiers and the spots
            coordinates as:

                {'spot_id': (tuple of int),
                 'raster': (tuple of int),
                 'x': numpy.array,
                 'y': numpy.array,
                 'z': numpy.array}

            where 'id' is the list of ids, 'raster' is the list
            of raster indices the spots belong to and 'x', 'y', 'z' the
            list of cartesian coordinates.

        Example:
            >>> spots = get_region_spots('Regions')
            >>> print(spots['spot_id'])
            (0, 1, 2, 3, 4)
        """

        params = {'regionid': region_id}
        response = self._connection.get('region/spots', params=params)
        return _cppserialization.deserializeRegionSpots(response.content)

    def get_spectra_matrix(self, spot_ids, normalization_id=None):
        """
        Retrieve multiple spectra

        Args:
            spot_ids (list of int): The spot_ids for which the spectra should
                be returned.
            normalization_id (string): The uuid or the name of the normalization to be used.
                Empty string or None (default) will return the non-normalized spectra matrix. If the
                same string is both a valid uuid and a name, it is interpreted as uuid.
                For the available normalizations, see :func:`DatasetProxy.get_normalizations`.

        Returns:
            :obj:`SpectraMatrix`: the intensities, spot ids and mx of the
            queried spectra.
        """

        data = _cppserialization.serializeSpectraMatrixParams(spot_ids, normalization_id)
        response = self._connection.post('spectramatrix', data=data)
        return _cppserialization.deserializeSpectraMatrix(response.content)

    def get_region_tree(self):
        """
        Retrieve the region tree

        Returns:
            :obj:`RegionTree`: a thin wrapper around the backengine RegionTree
            object.
        """
        params = {
            'mode': 'all'
        }
        response = self._connection.get('regions', params=params)
        return _cppserialization.deserializeRegionTree(response.content)

    def get_labels(self):
        """
        Retrieve labels

        Returns:
            list of :obj:`Label`: the list of available labels. The order
            of the labels is not predictable.
        """
        response = self._connection.get('labels')
        return _cppserialization.deserializeLabels(response.content)

    def write_label(self, name, spot_label):
        """
        Write labels into the dataset

        Args:
            name (string): a descriptive name for this label.
            spot_label (dict of int:int): the labels for each spot.

        Returns:
            :obj:`string`: The unique identifier that is assigned to the written label by the
            server.
        """
        data = _cppserialization.serializeLabels(name, spot_label)
        response = self._connection.post('label', data=bytes(data))
        label_id = response.text
        return label_id

    def get_region_polygons(self, region_id):
        """
        Retrieve the polygon information for a region

        Args:
            region_id (string): the identifier of the region.

        Returns:
            list of list of :obj:`Point`: a list of polygons,
            where each polygon is defined from its vertices.
        """

        params = {'regionid': region_id}
        response = self._connection.get('region/polygons', params=params)
        
        return _cppserialization.deserializeRegionPolygons(response.content)

    def get_region_attributes(self, region_id):
        """
        Retrieve attributes for a region

        Args:
            id (string): the identifier of the region.

        Returns:
            dict: the attributes of the region.
        """
        params = {'regionid': region_id}
        response = self._connection.get('region/attributes', params=params)

        return _cppserialization.deserializeRegionAttributes(response.content)

    def get_spot_image_ids(self, name=None, group_name=None):
        """
        Query spot image IDs

        Args:
            name (string): the name of the requested image.
            group_name (string): the name of the group the image.

        Only the specified selection criteria will be utilized. If
        all arguments are left, all available spot image IDs are retrieved.

        Returns:
            list of :obj:`string`: the IDs of the queried images. The order
            of the IDs is not guaranteed.

        Raises:
            TypeError: if `name` or `group_name` are not strings.
        """
        if name is None:
            name = str()
        if group_name is None:
            group_name = str()

        params = {
            'name': name,
            'group': group_name
        }

        response = self._connection.get('spotimageids', params=params)
        return _cppserialization.deserializeSpotImageIds(response.content)

    def get_spot_image(self, spot_image_id, lightweight=False):
        """
        Retrieve a spot image

        Args:
            spot_image_id (string): the identifier of the spot image.
            lightweight (bool): if True, the returned image will not
                contain spots and values.

        Returns:
            A spot image. It can be of type :obj:`IntensitySpotImage`,
            :obj:`RGBSpotImage` or :obj:`ScoreSpotImage`.

        Raises:
            ValueError: if the backengine did not return a valid image or if
                an image of unsupported type is detected.
        """
        params = {
            'spotimageid': spot_image_id,
            'lightweight': lightweight
        }
        response = self._connection.get('spotimage', params=params)
        return _cppserialization.deserializeSpotImage(response.content)

    def write_normalization( self, name, values, scale_to_average = False):
        """Write a custom normalization

        Note:
            The mean spectra of all regions according to the new normalization
            are not computed immediately, but only when the dataset with the
            new normalization is first opened in SCiLS Lab. Thus, it is not
            possible to retrieve a region mean spectrum for the new
            normalization using DatasetProxy.get_mean_spectrum() directly
            after creating the normalization.

        Args:
            name (string): The name for the new normalization. A normalization
                with this name must not already exist.
            values (array_like): The normalization values. Must be one value
                per spot in the data set in the order of the spots in the data
                set. Must not contain non-finite values or values smaller or
                equal to zero.
            scale_to_average (bool, optional): A boolean value that defines
                if a scaling factor is applied to the normalization values.
                The normalization values are divided by their mean. 
                This keeps the overall intensity of the normalized spectra
                comparable to the non-normalized spectra. Note that normalizations
                calculated in SCiLS Lab are similarly scaled. Defaults to False.

        Raises:
            ValueError: If the normalization values contain non-finite values,
                values outside the float range or if the normalization cannot
                be written.

        Returns:
            :obj:`string`: The unique identifier of the newly written normalization
        """

        values = numpy.array(values, dtype=numpy.float64)
        if not numpy.isfinite(values).all():
            raise ValueError("Cannot write normalization: values array contains non-finite values")

        values_float = numpy.array(values).astype(numpy.float32)
        if not numpy.isfinite(values_float).all():
            raise ValueError("Cannot write normalization: values array contains values outside float range")
        
        data = _cppserialization.serializeNormalization(name, values_float, scale_to_average)
        response = self._connection.post('normalization', data=data)
        return response.text
        
    def write_intensity_spot_image(
            self,
            name,
            group_name,
            spot_ids,
            values,
            user_info=None):
        """
        Write an intensity spot image

        In SCiLS Lab, intensity spot images behave similar to ion intensities.
        They react to normalization and hot spot removal.

        Note:
            The spot image values are stored in SCiLS Lab with float precision.
            Reading a spot image back will therefore typically not return the exact
            same values that were written.

        Args:
            name (string): the name of the image. Multiple images can share the
                same name.
            group_name (string): a name identifying a group the image belongs
                to.
            spot_ids (iterable of int): the list of spot IDs the values
                are associated to. The list must be sorted in ascending order
                and match the length of `values`. Note that intensity spot
                images belonging to the same group must have the same spot_ids.
            values (iterable of float): a list of scalars representing
                the intensities at each spot.
            user_info (dictionary {string: string}): a dictionary of user-defined
                information associated with this spot image.

        Returns:
            :obj:`string`: the unique identifier of the written image.
        """

        data = _cppserialization.serializeIntensitySpotImage(
            name, group_name, spot_ids, values, user_info
        )
        response = self._connection.post('intensityspotimage', data=data)
        return response.text

    def write_score_spot_image(
            self,
            name,
            group_name,
            spot_ids,
            values,
            value_range=None,
            user_info=None):
        """
        Writes a score spot image

        In SCiLS Lab, score spot
        images are shown with a fixed value range and they are not affected
        by the normalization setting.

        Note:
            The spot image values are stored in SCiLS Lab with float precision.
            Reading a spot image back will therefore typically not return the exact
            same values that were written.

        Args:
            name (string): the name of the image. Multiple images can share the
                same name.
            group_name (string): a name identifying a group the image belongs
                to.
            spot_ids (iterable of int): the list of spot IDs the values
                are associated to. The list must be sorted in ascending order
                and match the length of `values`. Note that score spot
                images belonging to the same group must have the same spot_ids.
            values (iterable of float): a list of scalar representing
                the intensities at each spot.
            value_range (2-ple of float): the lower and upper value range
                associated with the Score image. When not provided as input, it
                will be set to the min and max of the values array.
            user_info (dictionary {string: string}): a dictionary of user-defined
                information associated with this spot image.

        Returns:
            :obj:`string`: the unique identifier of the written image.
        """
        data = _cppserialization.serializeScoreSpotImage(name, group_name, spot_ids, values, value_range, user_info)
        response = self._connection.post('scorespotimage', data = data)
        return response.text

    def write_rgb_spot_image(
            self,
            name,
            group_name,
            spot_ids,
            values,
            user_info=None):
        """
        Write an RGB spot image

        RGB spot images
        are displayed in SCiLS Lab using the specified RGB values
        and they are not affected by any scaling or normalization
        settings.

        Args:
            name (string): the name of the image. Multiple images can share the
                same name.
            group_name (string): a name identifying a group the image belongs
                to.
            spot_ids (iterable of int): the list of spot IDs the values
                are associated to. The list must be sorted in ascending order
                and match the length of `values`. Note that scalar spot
                images belonging to the same group must have the same spot_ids.
            values (iterable of string or of rgb values): a list of rgb values representing
                the color at each spot. Each rgb val is represented as a hex
                string eg: #0013ff or as a list of rgb values with range 0...255 eg. [0, 100, 200]
            user_info (dictionary {str: str}): a dictionary of user-defined
                information associated with this spot image.

        Returns:
            :obj:`string`: the unique identifier of the written image.
        """
        rgb_values = []
        if len(values) > 0:
            if isinstance(values[0], str):
                for hex_val in values:
                    h = hex_val.lstrip('#')
                    rgb_values.append(list(int(h[i:i+2], 16) for i in (0, 2, 4)))
            else:
                try:
                    iter(values[0])
                    rgb_values = values
                except TypeError as err:
                    raise Exception("Invalid input: values has an invalid format") from err
        else:
            raise Exception("Invalid input: values is empty")
        return self._write_rgb_spot_image(name, group_name, spot_ids, rgb_values, user_info)

    def _write_rgb_spot_image(
            self,
            name,
            group_name,
            spot_ids,
            values,
            user_info=None):
        """
        Save an rgb spot image to file.

        Args:
            name (string): the name of the image. Multiple images can share the
                same name.
            group_name (string): a name identifying a group the image belongs
                to.
            spot_ids (iterable of int): the list of spot IDs the values
                are associated to. The list must be sorted in ascending order
                and match the length of `values`. Note that scalar spot
                images belonging to the same group must have the same spot_ids.
            values (iterable of array of int): a list of rgb values representing
                the color at each spot. Each rgb val is represented a list of int of
                range 0-255 eg. [0, 100, 255]
            user_info (dictionary {str: str}): a dictionary of user-defined
                information associated with this spot image.

        Returns:
            :obj:`string`: the unique identifier of the written image.
        """

        data = _cppserialization.serializeRGBSpotImage(name, group_name, spot_ids, values, user_info)
        response = self._connection.post('rgbspotimage', data = bytes(data))
        return response.text


    def print_spot_image_summary(self):
        """ Print a summary of available spot images """
        all_ids = self.get_spot_image_ids()
        all_images = [
            self.get_spot_image(uid, lightweight=True)
            for uid in all_ids]
        # Sort the images by group and then by name.
        all_images = sorted(all_images, key=lambda x: (x.group_name, x.name))

        print("Found {} spot images\n".format(len(all_images)))
        for image in all_images:
            for entry in [
                    ('Id', image.id),
                    ('Name', image.name),
                    ('Group name', image.group_name)]:
                print(indent('{}: {}'.format(
                    entry[0], entry[1]), ' ' * 2))
            print("")
