#
# This file is part of the SCiLS Lab Python API client (scilslab).
#
# Copyright (C) 2020 - 2025, Bruker Daltonics GmbH & Co. KG, Bremen, Germany
# Contact: support.scils@bruker.com
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; version 2.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.
# If not, see <http://www.gnu.org/licenses/gpl-2.0.html>.
# SPDX-License-Identifier: GPL-2.0-only
#
# In addition to GPL2, this program can be provided by Bruker Daltonics
# under alternative licensing models. For more information on
# alternative options, please contact support.scils@bruker.com.
#
"""
A module to start and manage SCiLSLab Server sessions.
"""
from functools import total_ordering
import os
import re
import secrets
import string
import subprocess
import tempfile
import time
import warnings
import weakref

from scilslab.client import DatasetProxy
from scilslab._connection import _APIVersion


class LocalSession:
    """
    A context class which starts a local server session and loads a file to
    be accessed via REST API, and creates a dataset proxy which can be used to
    query the data. This class is intended to be used locally,
    for security reasons the server will only accept connections from the local machine.
    Additionally it is recommended to block access to the server from the network by
    a firewall. The interaction with the dataset is handled through the 'dataset_proxy'
    of this object.

    Examples:

        The class can be used as a context (suggested), in the following way:

        ::

            with LocalSession(filename='mydata.slx') as session:
                dataset = session.dataset_proxy
                version = dataset.get_server_version()


        or it can be used by starting explicitely a session and
        retrieving directly the client. Note that in this case you
        should call close() at the end of your script or interactive
        session to properly terminate the server process.

        ::

            session = LocalSession(filename='mydata.slx')
            dataset = session.dataset_proxy
            version = dataset.get_server_version()
            ...
            session.close()
    """
    def __init__(
            self,
            filename,
            executable=None,
            port=8086,
            timeout=90,
            retries=2,
            sleep=0.1,
            license_serial=None,
            auto_migrate_files=False,
            backup_upon_migration=True,
            override_filesystem_check=False):
        """
        Construct and start local server session.

        Args:

            filename (str): the path to the data file to be served.

            executable (str): the full path where the executable scilsMsServer.exe
                is located. If not provided, a guess will be attempted
                using the following locations:

                - The path stored in an environment variable SCILSMSSERVER
                - ``C:\\Program Files\\SCiLS\\SCiLS Lab\\scilsMsServer.exe``

            port (int): the port to start the connection on. The connection
                will be started on localhost:XXXX, where XXXX is the
                selected port.

            timeout (int): interval to wait for server confirmation
                (in seconds).

            retries (int): number of client retries when a request fails and no
                response was received by the server. Set to 0 to disable,
                set to 1 or larger to circumvent idle connection issues.

            sleep (float): sleep time between retries in seconds.

            license_serial (str): the serial of the license to be used to
                start the server. If omitted, a serial is searched in the
                environment variable SCILSMSSERVER_LICENSE. If no license serial
                is provided, the server will automatically select one.

            auto_migrate_files (bool): Automatically migrate deprecated slx files 
                to the current version if necessary. Defaults to False.

            backup_upon_migration (bool): Specifies if a backup of the slx file
                shall be created upon file migration. Only has an effect if
                auto_migrate_files is True. Defaults to True.

            override_filesystem_check (bool): Allows to open dataset from unsafe file systems.
                This can lead to data corruption and is not recommended.
                Defaults to False.

        Raises:
            ConnectionError: if the server or client could not start properly
                or if the server is not reachable.
            ValueError: if the filename does not specify an existing file,
                if the executable can not be found, if 'auto_migrate_files' or
                'backup_upon_migration' are not of type 'bool'.
            RuntimeError: if the version of the server executable has an
                incompatible version.
        """
        # Initialize this attribute asap, so that the __del__ method
        # makes always sense.
        self.process = None
        """ :obj:`subprocess.Popen`: The process running the server.
        """
        self.dataset_proxy = None
        """:obj:`scilslab.DatasetProxy`: The dataset proxy associated to this
            session.

            All interaction with the dataset is handled by this object
        """

        self._timeout = max(timeout, 1)
        hostname = "127.0.0.1"

        self.executable = None
        """string: the full path to the server executable."""

        self._temp_dir = None
        self._stdout_writehandle = None
        self._stdout_readhandle = None
        self._finalizer = None

        filename, self.executable = _check_arguments(filename, executable)

        if type(auto_migrate_files) is not bool:
            raise ValueError("'auto_migrate_files' must be of type bool.")

        if type(backup_upon_migration) is not bool:
            raise ValueError("'backup_upon_migration' must be of type bool.")

        self._server_version = self._executable_version()
        
        client_version = _APIVersion.from_version_string(DatasetProxy.client_version)
        
        if self._server_version.major > client_version.major:
            message = "The API server executable is not compatible with the installed"\
                " scilslab package\n"\
                " Server executable major version: {}"\
                " scilslab package major version: {}\n"\
                " Please upgrade the scilslab package."
            raise RuntimeError(
                message.format(self._server_version.major, client_version.major)
            )

        self.authentication_token = _generate_authentication_token(length=12)
        """string: The authentication token.
        
            This authentication token is generated
            internally and used to to authenticate with the server. If
            additional :obj:`scilslab.DatasetProxy` objects have to connect
            to this server, for example in multiprocessing, 
            this token must be provided as their input parameter."""

        try:
            args = self._build_command_line(
                filename,
                port,
                license_serial,
                auto_migrate_files,
                backup_upon_migration,
                override_filesystem_check)
        except:
            raise

        # Set up temporary file to spool subprocess stdout
        self._temp_dir = tempfile.TemporaryDirectory()
        temp_file_name = os.path.join(self._temp_dir.name, "serverlog")
        self._stdout_writehandle = open(temp_file_name, 'w+t')
        self._stdout_readhandle = open(temp_file_name, 'rt', errors='replace')

        # Start the process.
        self.process = subprocess.Popen(
            args,
            stdin=subprocess.PIPE,
            stdout=self._stdout_writehandle,
            stderr=subprocess.STDOUT,
            bufsize=0,
            text=True,
            creationflags=subprocess.CREATE_NO_WINDOW)

        # Register the finalizer
        self._finalizer = weakref.finalize(
            self,
            LocalSession._cleanup,
            self.process,
            self._stdout_readhandle,
            self._stdout_writehandle,
            self._temp_dir,
            self._timeout,
            self._server_version)

        # Verify that the server process is running and ready.
        start = time.time()
        self.server_log = ""
        """string: The server log
        
        Contains the output written to the console by the server
        upon startup.
        """

        success = False
        timed_out = True
        while time.time() < start + self._timeout:

            self.server_log = self._read_stdout_tempfile()
            if 'REST server active' in self.server_log:
                _raise_startup_warnings(self.server_log)
                success = True
                break
            
            if self.process.poll() is not None:
                
                self.server_log = self._read_stdout_tempfile()
                if '[ERROR]' in self.server_log:
                    self.close()
                    raise RuntimeError(
                        "Cannot start the server. An error was reported at server startup: \n{}".format(
                        self.server_log))
                else:
                    timed_out=False
                    break

        if not success:
            if timed_out:
                msg = "Timeout during startup. Try to increase the timeout."
            else:
                msg = "Cannot obtain server status."

            self.server_log = self._read_stdout_tempfile()
            
            msg += "\nServer log: {}".format(self.server_log)
            self.close()
            raise RuntimeError(msg)

        # Try to establish connection. If it fails, try to determine the
        # problem.
        try:
            self.dataset_proxy = DatasetProxy(
                    authentication_token=self.authentication_token,
                    hostname=hostname,
                    port=port,
                    retries=retries,
                    sleep=sleep)
        except ConnectionError as error:
            self.close()
            raise ConnectionError(
                "Cannot start session. Attempt to create the dataset proxy "
                "failed.") from error
        except Exception as ex:
            self.close()
            raise ex

    @staticmethod
    def _cleanup(process, readhandle, writehandle, tempdir, timeout, server_version):
        """
        Callback for the finalization. 
        Closes the readhandle, the writehandle, cleans up the tempdir and
        kills the process.
        
        Raises:
            timeoutError: if the server process did not terminate within
                the timeout.
        """
        # Early exit by failed constructor.
        if process is None:
            if readhandle is not None:
                readhandle.close()
            if writehandle is not None:
                writehandle.close()
            if tempdir is not None:
                tempdir.cleanup()
            return

        if process.poll() is not None:
            log = None
            # If we get here it means that the server is already terminated.
            # Check if there is new information to display.            
            if not readhandle.closed:
                log = readhandle.read()
                readhandle.close()
                writehandle.close()
                tempdir.cleanup()
            if log:
                warnings.warn(
                    "Server terminated with return code {} "
                    "and log: \n{}".format(process.returncode, log),
                    RuntimeWarning)
        else:
            # Regular termination and cleanup.

            # For server 8.1 and greater attempt graceful shutdown first
            if server_version >= _APIVersion(8,1):
                try:
                    process.communicate('quit', timeout)
                    readhandle.close()
                    writehandle.close()
                    tempdir.cleanup()
                    return
                except subprocess.TimeoutExpired:
                    pass

            process.terminate()
            try:
                process.wait(timeout)
            except subprocess.TimeoutExpired:
                raise TimeoutError("Can not terminate server process")
            finally:
                readhandle.close()
                writehandle.close()
                tempdir.cleanup()

    def close(self):
        """
        Terminate the server process. This method should be invoked
        at the end of the session if the session did not run as context.

        Raises:
            timeoutError: if the server process did not terminate within
                the timeout.
        """
        if self._finalizer is not None:
            self._finalizer()
        else:
            self._cleanup(
                self.process,
                self._stdout_readhandle,
                self._stdout_writehandle,
                self._temp_dir,
                self._timeout,
                self._server_version)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def __del__(self):
        # Clean up upon collection. Make sure that the process pipe is empty.
        self.close()

    def _read_stdout_tempfile(self):
        self._stdout_readhandle.seek(0)
        return self._stdout_readhandle.read()

    def _build_command_line(
            self,
            filename,
            port,
            license_serial,
            auto_migrate_files,
            backup_upon_migration,
            override_filesystem_check):
        args = [
            self.executable,
            '-f',
            filename,
            '-p',
            str(port),
            '-a',
            self.authentication_token]

        # If no license was specified, look in the environment variables.
        if license_serial is None and 'SCILSMSSERVER_LICENSE' in os.environ:
            license_serial = os.environ['SCILSMSSERVER_LICENSE']
        if license_serial is not None:
            args += ['-l', str(license_serial)]
        if auto_migrate_files:
            args += ['-m']
            if backup_upon_migration:
                if self._server_version < _APIVersion(5,1):
                    raise RuntimeError(
                        'Automatic migration of files with backup requires at least'\
                        ' server version 5.1\n'\
                        'Upgrade the server or set \'backup_upon_migration\' to False'
                    )
            else:
                if self._server_version >= _APIVersion(5,1):
                    args += ['--no-backup']

        if override_filesystem_check:
            args += ['--override-fs-check']

        return args

    def _executable_version(self):
        """Retrieve the version of scilsmsserver executable"""
        version_string = subprocess.run(
            [self.executable, '--version'],
            capture_output=True,
            check=False,
            text=True,
            timeout=10).stdout

        return _APIVersion.from_version_string(version_string)
    
    
def _raise_startup_warnings(serverlog):
    """Parses serverlog and raises warnings

    Reads a server log and raises a user warning for each line
    that starts with '[WARNING]'. The warning message will be
    the content of that line.

    Args:
        serverlog (string): The server log
    """
    regex = re.compile(r"\[WARNING\](.*)$", re.M)
    warning_strings = regex.findall(serverlog)
    for warning_string in warning_strings:
        warnings.warn(warning_string)
        

def _check_arguments(filename, executable):
    """
    Check the validity of the input parameters filename and executable and
    returns a default choice if None is given.

    Raises: ValueError if invalid arguments ar provided
    """
    if not os.path.exists(filename):
        raise ValueError(
            "The file {} was not found. "
            "Please provide a valid path.".format(
                filename))

    if executable is None:
        executable = _find_executable()
    if executable is None:
        raise ValueError(
            "An executable was not provided and a could not be "
            "found in the default locations. Please provide a "
            "full path.")
    if not os.path.exists(executable):
        raise ValueError(
            "An executable was provided but could not be found. "
            "Please provide a valid path.")

    return filename, executable


def _find_executable():
    """
    Look for an executable called scilsMsServer.exe. We are lookin inside
    (in order):
        - The path stored in an environment variable SCILSMSSERVER
        - /Program Files/SCiLS/SCiLS Lab/

    Raises:
        ValueError: if a path is specified in the environment variable
        SCILSMSSERVER but the executable was not found.
    """
    if 'SCILSMSSERVER' in os.environ:
        path = os.path.abspath(os.environ['SCILSMSSERVER'])
        if path[-1] == ";":
            path = path[:-1]
        if os.path.exists(path):
            return path
        raise ValueError(
            "The path {} is specified in the environment variable "
            "SCILSMSSERVER, but the executable does not exist.".format(
                path))
    path = os.path.join(
        r'C:\\', r'Program Files', 'SCiLS', 'SCiLS Lab', 'scilsMsServer.exe')

    if os.path.exists(path):
        return path

    return None


def _generate_authentication_token(length):
    """ Generate a default authentication token """
    characters = string.ascii_letters + string.punctuation + string.digits
    return "".join(secrets.choice(characters) for x in range(length))
