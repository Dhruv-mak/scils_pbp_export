#
# This file is part of the SCiLS Lab Python API client (scilslab).
#
# Copyright (C) 2020 - 2025, Bruker Daltonics GmbH & Co. KG, Bremen, Germany
# Contact: support.scils@bruker.com
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; version 2.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.
# If not, see <http://www.gnu.org/licenses/gpl-2.0.html>.
# SPDX-License-Identifier: GPL-2.0-only
#
# In addition to GPL2, this program can be provided by Bruker Daltonics
# under alternative licensing models. For more information on
# alternative options, please contact support.scils@bruker.com.
#
"""
This module contains the feature table interface for the SCiLSLab rest API.
"""

import numpy as np
import pandas as pd

from scilslab import _cppserialization
from scilslab._connection import _Connection
from scilslab.types import _check_interval_parameters
from scilslab.types import IonIntensities

class FeatureTableProxy:
    """
    The FeatureTableProxy class contains the methods to get and write information
    from and to the feature table of a data set provided by a server.
    This object is not intended to be instantiated on its own, rather it is
    instantiated by the DatasetProxy, the instance can be retrieved through
    the dataset proxy.
    """

    def __init__(
            self,
            connection: _Connection,
            ):
        """
        Create a dataset proxy and connect to a SCiLSLab server.

        Args:
            connection (scilslab._connection): The API client connection
        """
        self._connection = connection


    def create_empty_feature_list(self, name, allow_duplicate_name = False):
        """Create a new empty feature list


        Args:
            name (string): The name of the new feature list.
            allow_duplicate_name (bool, optional): Specifies if it is allowed to
                create a feature list with an already existing name. Defaults to False.

        Returns:
            :obj:`string`: The unique ID of the new feature list.

        Raises:
            value_error: If the new feature list name already exists and
                allow_duplicate_name is set to false.
        """

        params = {
            'name': name,
            'allowDuplicateName': allow_duplicate_name
        }

        response = self._connection.post('featurelist', json=params)
        return response.text

    def get_feature_lists(self):
        """Get an overview over all feature lists

        Returns:
            pandas.DataFrame: A DataFrame with the following columns:

                'id': The unique identifier of the feature list.
                'name': The name of the feature list.
                'num_features': The number of features in the feature list.
                'has_mz_features': If the list contains at least one
                plain m/z feature.
                'has_mobility_intervals': If the list contains at least
                one mobility interval.
                'has_ccs_features': If the list contains at least one
                ion mobility feature with intensity values.

        Raises:
            value_error: If the request to the API server fails.

        Note:
            If the API server has a higher minor version number than the client
            and SCiLS Lab introduced new feature types, the return value of
            this function may contain additional columns.
        """

        response = self._connection.get('featurelists')
        return _cppserialization.deserializeFeatureLists(response.content)

    def get_features(
        self,
        feature_list_id = None,
        feature_list_name = None,
        mode = None,
        include_all_user_columns = False,
        include_visible_user_columns = False):
        """Get the features of a feature list

        Note: The layout of the result can change in later versions of SCiLS Lab if new
            functionality is added. It is especially possible that new columns are added.
            To write scripts that stay forward- and/or backward compatible it is strongly
            recommended to access the columns by their name, not their index.

        Args:
            feature_list_id (string, optional): The unique identifier of the
                peaklist. None is converted to an empty string that indicates the
                "All features" feature list. Defaults to None.
            feature_list_name (string, optional): The name of the feature list to be retrieved.
                If a name is given, then no feature_list_id must be given. Defaults to None.
            mode (string, optional): The interval processing mode to be used. Must be either
                'area', 'max', 'mean' or 'sum'. If not given 'area' is used. 
                Ion mobility can only report having data with modes 'sum' or 'area'.
                Defaults to None.
            include_all_user_columns (bool, optional): Include all user defined feature
                list columns. Defaults to False.
            include_visible_user_columns (bool, optional): Include all user defined feature list
                columns that are set to visible in the SCiLS Lab data set. Defaults to False.

        Returns:
            pandas.DataFrame: A DataFrame with the following columns:

                'id': The IDs of the features.
                'mz_low': The lower bound of the mz interval for the feature.
                'mz_high': The upper bound of the mz interval for the feature.
                If the dataset is mobility enabled:
                'one_over_k0_low': The lower bound of the 1/k0 interval.
                'one_over_k0_high': The upper bound of the 1/k0 interval.
                If the collisional cross section values are available for the
                dataset:
                'ccs_low': The lower boundary of the ccs window.
                'ccs_high': The upper boundary of the ccs window.
                For all datasets:
                'name': The name of the feature.
                'root_region_intensity': The non-normalized average intensity
                of the feature for the entire dataset with the default
                interval processing mode.
                'color': The color string of the feature.
                For iprm-PASEF datasets:
                'type': The type of the signal (precursor or fragment).
                'isolation_window': Which isolation window a signal belongs to.
                For all datasets:
                'has_data': Indicates if intensity values for this feature
                exist.
                Additional columns with the user defined columns if selected.
        """

        if feature_list_id is None:
            feature_list_id = str()

        if feature_list_name is None:
            feature_list_name = str()

        if mode is None:
            mode = 'area'

        params = {
            'featurelistid': feature_list_id,
            'featurelistname': feature_list_name,
            'allusercolumns': include_all_user_columns,
            'visibleusercolumns': include_visible_user_columns,
            'intervalprocessingmode': mode
        }

        response = self._connection.get('featurelist', params=params)

        return _cppserialization.deserializeFeatureListColumns(response.content)

    def write_mz_features(self, feature_list_id, mz_intervals, names = None ):
        """Write mz features to a feature table

        Args:
            feature_list_id (string): The unique ID of the feature list.
            mz_intervals (Iterable of 2-ples): An list of 2-ples representing
                intervals defined by their lower and upper bound.
            names ([type], optional): An iterable with the names. If None names are set.
            Defaults to None.

        Returns:
            numpy array of :obj:`int`: The IDs of the new m/z features in the order in which
            they were specified. If a feature was not written because it is
            (fully or partially) outside the m/z axis, it is denoted as -1.
        """

        _check_interval_parameters(mz_intervals, 'mz_intervals', 'write_mz_features')

        intervals = list(zip(*mz_intervals))

        if names is None:
            names = []

        data = _cppserialization.serializeMzFeatures(feature_list_id, intervals[0], intervals[1], names )
        response = self._connection.post('mzfeatures', data=bytes(data))
        new_ids = _cppserialization.deserializeFeatureIDs(response.content)

        return new_ids

    def write_ccs_feature(
        self,
        feature_list_id,
        mz_interval,
        one_over_k0_interval,
        spot_ids,
        values,
        name = None):
        """Write an ion mobility feature with values into a feature list

        Args:
            feature_list_id (string): The unique ID of the feature list.
            mz_interval (2-ple of float): the lower and upper m/z value
                associated with the CCS feature.
            one_over_k0_interval (2-ple of float): the lower
                and upper value of inverse reduced mobility (1/K0) associated
                with the CCS image.
            spots_ids (iterable of int): the list of spot IDs the values
                are associated to. The list must be sorted in ascending order
                and match the length of `values`.
            values (iterable of float): a list of scalar representing
                the intensities at each spot.
            name (string, optional): [description]. Defaults to None.

        Returns:
            :obj:`int`: The ID of the written feature
        """

        data = _cppserialization.serializeCCSFeature(
            feature_list_id,
            mz_interval,
            one_over_k0_interval,
            spot_ids,
            values,
            name
        )

        response = self._connection.post('ccsfeature', data=data)
        feature_id = _cppserialization.deserializeFeatureId(response.content)

        return feature_id

    def write_external_feature(
        self,
        feature_list_id,
        spot_ids,
        values,
        name):
        """Write an external feature with values into a feature list

        Args:
            feature_list_id (string): The unique ID of the feature list.
            spots_ids (iterable of int): the list of spot IDs the values
                are associated to. The list must be sorted in ascending order
                and match the length of `values`.
            values (iterable of float): a list of scalar representing
                the intensities at each spot.
            name (string): External features need a name specified.

        Returns:
            :obj:`int`: The ID of the written feature
        """

        """cpp_ext_feature = _Serialization.ExternalFeature()
        cpp_ext_feature.featureListId = feature_list_id
        for spot in spot_ids:
            cpp_ext_feature.spots.push_back(spot)
        for value in values:
            cpp_ext_feature.values.push_back(value)

        if name is not None:
            cpp_ext_feature.featureName = name"""

        data = _cppserialization.serializeExternalFeature(
            feature_list_id, spot_ids, values, name)

        response = self._connection.post('externalfeature', data=bytes(data))
        feature_id = _cppserialization.deserializeFeatureId(response.content)

        return feature_id

    def get_feature_intensities(
        self,
        feature_id,
        region_id = None,
        mode = None,
        normalization_id = None):
        """Retrieve the intensities of a feature for a region

        Args:
            feature_id (int): The ID of the feature.
            region_id (string, optional): The unique identifier of the region. If None the root
                region is used. Defaults to None.
            mode (string, optional): The interval processing mode. Can be either 'area', 'sum', 'mean'
                or 'max'. If None, 'area' is used. Ion mobility features can only
                be retrieved with modes 'area' or 'sum'. Defaults to None.
            normalization_id (string, optional): The uuid or the name of the normalization to be used.
                Empty string or None (default) will return the non-normalized intensities. If the
                same string is both a valid uuid and a name, it is interpreted as uuid.

        Returns:
            IonIntensities: :obj:`IonIntensities`: contains the spot_ids and their
            corresponding intensity values. Ion mobility features may contain
            numpy.nan values if the feature contains no data for the respective
            spots.

        Raises:
            ValueError: If the selected features contains no data for the given mode or if
                non-existing region_id, mode or normalization_id are given.
        """

        _feature_id = int(feature_id)

        if _feature_id < 0:
            raise ValueError( "'feature_id' must be non-negative" )

        if region_id is None:
            region_id = "Regions"

        if mode is None:
            mode = 'area'

        if normalization_id is None:
            normalization_id = str()

        params = {
            'featureid': _feature_id,
            'regionid': region_id,
            'mode': mode,
            'normid': normalization_id
        }

        response = self._connection.get('region/featureintensities', params = params)
        return _cppserialization.deserializeIonIntensities(response.content, region_id)

    def write_column( self, column_name, feature_ids, values, set_visible=True, allow_duplicate_name=False):
        """Write a column for the feature table

        Allows to write a column of numeric or string values into the feature
        table. The values in those columns are associated to features and
        independent from individual feature lists. These columns are shown
        in the main SCiLS Lab user interface and can therefore be used to
        sort the feature table. This enables workflows such as custom quantitation
        approaches or custom quality scoring of features.

        Args:
            column_name (string): The name of the new column. Must be unique
                unless allow_duplicate_name is set to True.
            feature_ids (iterable of int): The feature IDs for which the values
                are written. These must be regular integers, numpy or pandas integers. 
            values (iterable of numeric or string): The values that are written into
                the column. If all values are numeric, a numeric column is written,
                if all values are strings, a string column is written. Must have the
                same length as feature_ids. 
            set_visible (bool, optional): Specifies if the column should be visible
                in SCiLS Lab. Defaults to True.
            allow_duplicate_name (bool, optional): Allows to create columns with
                existing names. Defaults to False.

        Raises:
            TypeError: If not all feature_ids are integer. 
            TypeError: If not all values are of a numeric or string type.
            ValueError: The server reports an error if the column cannot be written.

        Returns:
            bool: A boolean value that indicates if the call was successful.
        """
        
        if not all([isinstance(x, (int, np.integer, np.unsignedinteger)) for x in feature_ids]):
            raise TypeError( "Not all feature_ids are integer" )
        
        string_column = None
        double_column = None
            
        if all( [isinstance(x, (float, np.number)) for x in values]):
            double_column = values
        elif all( [isinstance(s, (str, np.str_)) for s in values]):
            string_column = values
        else:
            raise TypeError( "Values are not all numeric or string" )

        data = _cppserialization.serializeFeatureTableColumn( 
            column_name, feature_ids, double_column, string_column, set_visible, allow_duplicate_name)
        
        result = self._connection.post("featuretablecolumn", data=data)

        return result != ""
    

def _make_feature_name(
    name,
    mz_low,
    mz_high,
    one_over_k0_low,
    one_over_k0_high,
    ccs_low,
    ccs_high,
    use_name,
    prefer_ccs_value,
    digits):

    if use_name and name != "":
        return name

    if np.isnan( (one_over_k0_low, one_over_k0_high, ccs_low, ccs_high ) ).all():
        return "m/z:" + str( round( np.mean((mz_low, mz_high)), digits) )

    if prefer_ccs_value and np.isfinite(ccs_low) and np.isfinite(ccs_high):
        return "m/z" + str( round( np.mean((mz_low, mz_high)), digits) ) +\
            "_ccs:" + str( round( np.mean((ccs_low, ccs_high)), digits) )

    return "m/z" + str( round( np.mean((mz_low, mz_high)), digits) ) +\
            "_1/k0:" + str( round( np.mean((one_over_k0_low, one_over_k0_high)), digits) )


def make_feature_names(
    features,
    use_name = True,
    prefer_ccs_values = True,
    digits = 3):
    """Make names for features

    When creating intensity tables or matrices from multiple features,
    it may be helpful to give the columns meaningful names. If a feature
    has an assigned name in the feature table, this name will be used unless
    the 'use:names' option is set to False. Otherwise the name will
    be generated from the center of the m/z interval and (if available)
    from the ion mobility interval.

    Args:
        features (pandas.DataFrame): A feature list as returned from
            FeatureTable.get_features()
        use_name (bool, optional): If True and the feature has a non-empty
            name, this name will be used. Defaults to True.
        prefer_ccs_values (bool, optional): If True and collisional cross
            section information is available, this will be used to generate
            the name. If False, the 1/k0 values will be used. This option
            has no effect in the case of plain m/z features. Defaults to True.
        digits (int, optional): The number of digits the numeric values are
            rounded to. Defaults to 3.

    Returns:
        list of :obj:`string`: A list of names for each feature.
        
            The names have a format
            of "m/z:xxx.xx" for plain m/z features and "m/z:xxx.xx_ccs:yyy.yy" or
            "m/z:xxx.xx_1/k0:yyy.yy" for ion mobility features.
    """

    _features = pd.DataFrame(features)

    if not 'one_over_k0_low' in _features.columns :
        _features.loc[:, 'one_over_k0_low'] = np.nan

    if not 'one_over_k0_high' in _features.columns:
        _features.loc[:, 'one_over_k0_high'] = np.nan

    if not 'ccs_low' in _features.columns:
        _features.loc[:, 'ccs_low'] = np.nan

    if not 'ccs_high' in _features.columns:
        _features.loc[:, 'ccs_high'] = np.nan

    feature_names = _features.apply(
        lambda x: _make_feature_name(
            x['name'],
            x['mz_low'],
            x['mz_high'],
            x['one_over_k0_low'],
            x['one_over_k0_high'],
            x['ccs_low'],
            x['ccs_high'],
            use_name,
            prefer_ccs_values,
            digits), axis=1 )

    return [str(x) for x in feature_names]
