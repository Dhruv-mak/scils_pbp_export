#
# This file is part of the SCiLS Lab Python API client (scilslab).
#
# Copyright (C) 2020 - 2025, Bruker Daltonics GmbH & Co. KG, Bremen, Germany
# Contact: support.scils@bruker.com
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; version 2.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.
# If not, see <http://www.gnu.org/licenses/gpl-2.0.html>.
# SPDX-License-Identifier: GPL-2.0-only
#
# In addition to GPL2, this program can be provided by Bruker Daltonics
# under alternative licensing models. For more information on
# alternative options, please contact support.scils@bruker.com.
#
"""
A module containing the data structures and methods to work with region trees.
"""

from collections import namedtuple
import ctypes
from dataclasses import dataclass
import pathlib
from textwrap import dedent
from textwrap import indent
from typing import OrderedDict

import numpy
import pandas

from scilslab import _cppserialization

class RegionTree:
    """
    A tree containing region information.
    This object is not intended to be instantiated on its own,
    it acts as return type for :obj:`scilslab.DatasetProxy.get_region_tree()`

    Attributes:
        name (str): The name of the region
        id (str): A unique identifier of the region
        spots (dict): The spots belonging to the region
        polygons (list of list of :obj:`scilslab.Point`): A list of polygons
            The region polygons for the region tree root.
            Each polygon is represented by a list of points defined from its vertices
        attributes (dict): The attributes of the region
        subregions (list of :obj:`scilslab.RegionTree`): The subregions of this region
          
    """

    def print(self):
        """
        Print region tree information.
        """
        indentation = self._depth * 2
        for entry in [
                ('Name', self.name.split('/')[-1]),
                ('Id', self.id),
                ('Number of spots', len(self.spots["spot_id"])),
                ('Attributes', self.attributes)]:

            print(indent('{}: {}'.format(entry[0], entry[1]), ' ' * indentation))
        print('\n')

        for subregion in self.subregions:
            subregion.print()


    def get_all_regions(self):
        """A flattened list of all subregions

        Returns:
            list of :obj:`scilslab.RegionTree`: A flat list of all
            subregions contained in this tree node.

            
        """
        regions = [self]
        for subregion in self.subregions:
            regions += subregion.get_all_regions()
        return regions


class SpectraMatrix(namedtuple('SpectraMatrix', ['spot_ids', 'intensities', 'mz'])):
    """
    A collection of Spectra corresponding to a list of spot.

    Attributes:
        spot_ids (tuple of int): the ids of the spots the spectra corresponds to.
        intensities (numpy.ndarray):
            a 2-dimensional array with shape (spots_ids, len(mz)) containing
            in each row the intensities of the spectrum associated with the
            corresponding spot_id.
        mz (numpy.array): the mass values.
    """
    def to_data_frame(self):
        """Convert to Pandas Dataframe

        Returns:
            :obj:`Pandas.Dataframe`: a data frame version of the
            intensities and mz values, tabulated in columns.
            Intensities are labelled as 'spot X', where X is the id
            of the corresponding spot.
        """
        labels = ['spot {}'.format(i) for i in self.spot_ids] + ['mz']
        dataframe = pandas.DataFrame(
            data=numpy.column_stack(
                (numpy.transpose(self.intensities), self.mz)),
            columns=labels
            )
        return dataframe


# For these simple primitives we use namedtuple as it's the easiest way to go.
# We override the docstring to get a nicer documentation.
Point = namedtuple('Point', ['x', 'y'])
Point.__doc__ = dedent("""\
    A point in the plane.

    Attributes:
        x (float): the position in x.
        y (float): the position in y.
    """)

Rectangle = namedtuple('Rectangle', ['x', 'y', 'width', 'height'])
Rectangle.__doc__ = dedent("""\
    A descriptor for a rectangular region.

    Attributes:
        x (int): the x position.
        y (int): the y position.
        width (int): the width.
        height (int): the height.
    """)

FileInfo = namedtuple('FileInfo', ['filepath', 'uuid'])
FileInfo.__doc__ = dedent("""\
    File information.

    Attributes:
        filepath (string): location of the current file.
        uuid (string): the unique id of the dataset.
    """)

Image = namedtuple('Image', [
    'rectangle',
    'values',
    'spotsize',
    'transformation',
    'region_id'])
Image.__doc__ = dedent("""\
    A descriptor for an image.

    Attributes:
        rectangle (:obj:`Rectangle`): the image boundary
        values (numpy.array of float): the image values on each spot.
        spotsize (tuple of floats): the size of the spot.
        transformation (numpy.ndarray): the transformation
            matrix.
        region_id (string): the id of the region used to query this image.
    """)

IntensitySpotImage = namedtuple('IntensitySpotImage', [
    'id',
    'name',
    'group_name',
    'spot_ids',
    'values',
    'user_info'])
IntensitySpotImage.__doc__ = dedent("""\
    An image composed by a vector of scalar values on the corresponding
    spots.

    Attributes:
        id (string): the unique identifier assigned from SCiLSLab to the image.
        name (string): the name of the image.
        group_name (string): the name of the group the image belongs to.
        spot_ids (numpy.array int): the array of spot ids for which the values are specified.
        values (numpy.array of float): the array of scalar values.
        user_info (dict): a dictionary of user-defined information, with keys
            and values as strings.
    """)

ScoreSpotImage = namedtuple('ScoreSpotImage', [
    'id',
    'name',
    'group_name',
    'spot_ids',
    'values',
    'value_range',
    'user_info'])
ScoreSpotImage.__doc__ = dedent("""\
    An image composed by a vector of scalar values on the corresponding
    spots and identified by a given range.

    Attributes:
        id (string): the unique identifier assigned from SCiLSLab to the image.
        name (string): the name of the image.
        group_name (string): the name of the group the image belongs to.
        spot_ids (numpy.array int): the array of spot ids for which the values are specified.
        values (numpy.array of float): the array of scalar values.
        value_range (2-ple of float): the lower and upper range value for the Score image.
        user_info (dict): a dictionary of user-defined information, with keys
            and values as strings.
    """)
RGBSpotImage = namedtuple('RGBSpotImage', [
    'id',
    'name',
    'group_name',
    'spot_ids',
    'values',
    'user_info'])
RGBSpotImage.__doc__ = dedent("""\
    An image composed by a vector of rgb values on the corresponding
    spots

    Attributes:
        id (string): the unique identifier assigned from SCiLSLab to the image.
        name (string): the name of the image.
        group_name (string): the name of the group the image belongs to.
        spot_ids (numpy.array int): the array of spot ids for which the values are specified.
        values (string list): the array of rgb hex values, eg. one rgb val = #23aaff
        user_info (dict): a dictionary of user-defined information, with keys
            and values as strings.
    """)

Label = namedtuple('Label', ['id', 'name', 'spot_label'])
Label.__doc__ = dedent("""\
    A descriptor for a label container.

    Attributes:
        id (string): a unique identifier.
        name (string): a descriptive name.
        spot_label (dict): a dictionary mapping spectra to label.
    """)

IonIntensities = namedtuple('IonIntensities', ['spot_ids', 'values', 'region_id'])
IonIntensities.__doc__ = dedent("""\
    A descriptor for the ion intensities container.

    Attributes:
        spot_ids (numpy.array int): the array of spot ids for which the intensities are specified.
        values (numpy.array of float): the array of scalar valued intensities.
        region_id (str): the id of the region used to query this image.
    """)

FeatureListInfo = namedtuple(
    'FeatureListInfo',
    [
        'id',
        'name',
        'num_features'
        ]
    )

FeatureListInfo.__doc__ = dedent("""\
    A descriptor for the feature list info container.

    Attributes:
        id (string): the id string of the feature list.
        name (string): the name of the feature list.
        num_features (int): the number of features in the feature list.
        has_mz_features (bool): True if the feature list contains plain m/z intervals.
        has_mobility_intervals (bool): True if the feature list contains features with ion mobilities.
        has_ccs_features (bool): True if ion mobility features with data are present.  
    """)

ExternalImage = namedtuple(
    "ExternalImage",
    [
        'path',
        'px2world',
        'metadata'
    ]
)

ExternalImage.__doc__ = dedent(
    """A descriptor for an external optical image

    Attributes:
       path (string): The path to the external optical image.
       px2world (array): A 4x4 pixel to world transformation matrix.
       metadata (dict): A dict that contains optional additional metadata
            about the image, such as width, height, type or a hash value.
    """
)


OpticalImage = namedtuple(
    "OpticalImage",
    [
        'id',
        'name',
        'type',
        'data',
        'px2world',
        'spots',
        'external_image'
    ]
)

OpticalImage.__doc__ = dedent("""\
    A descriptor for the optical image container.

    Attributes:
        id (string): The unique identifier of the optical image.
        name (string): The name of the optical image.
        type (string): The type of the optical image.
        data (bytes): The binary data blob of the optical image.
        px2world (numpy.array): A 4x4 transformation matrix
            for the transformation of the optical image into
            the SCiLS Lab world coordinates.
        spots (list of int): The spot IDs of the spectra
            associated with the optical image.
        external_image( :obj:`FileInfo` or None): Information about the
            external optical image if one exists, None otherwise.

    """

)


def _check_interval_parameters(intervals, parameter_name, function_name):
    """
    Checks if intervals is an iterable of numeric 2-ples.

    Args:
        intervals (any): The object to be tested.
        function_name (str): The name of the function to
            be reported in the error messages.

    Raises:
        TypeError: if any of the parameters has the wrong type.
        ValueError: if the intervals have wrong bounds.
    """
    # For intervals, check first that it is an iterable.
    try:
        iter(intervals)
    except TypeError:
        raise TypeError(
            "The parameter {} in {} must be iterable.".format(
                parameter_name,
                function_name
                )
            )

    # Then check that iterating on it we have 2-ple with floats.
    # Upper/lower ordering is performed in the backengine.
    for interval in intervals:
        try:
            float(interval[0])
            float(interval[1])
        except ValueError:
            raise ValueError(
                "The parameter {} in {} must contain 2-ple of numbers.".format(
                    parameter_name,
                    function_name
                    )
                )

