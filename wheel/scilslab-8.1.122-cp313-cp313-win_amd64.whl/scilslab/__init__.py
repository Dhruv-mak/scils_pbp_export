#
# This file is part of the SCiLS Lab Python API client (scilslab).
#
# Copyright (C) 2020 - 2025, Bruker Daltonics GmbH & Co. KG, Bremen, Germany
# Contact: support.scils@bruker.com
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; version 2.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.
# If not, see <http://www.gnu.org/licenses/gpl-2.0.html>.
# SPDX-License-Identifier: GPL-2.0-only
#
# In addition to GPL2, this program can be provided by Bruker Daltonics
# under alternative licensing models. For more information on
# alternative options, please contact support.scils@bruker.com.
#
"""
REST-API for SCiLSLab.

This packages allows to access mass spectroscopy data from SCiLSLab.
For more information about SCiLSLab visit:
https://scils.de
https://www.bruker.com/products/mass-spectrometry-and-separations/ms-software/scils.html

Copyright 2020 - 2025, Bruker Daltonics GmbH & Co. KG
For Research Use Only - not for use in clinical diagnostic procedures.
"""
# Import the backengine.
from .lib import cppserialization as _cppserialization
from ._version import __version__

# Direct imports for convenience.
from scilslab.client import DatasetProxy
from scilslab.feature_table import FeatureTableProxy
from scilslab.optical_images import OpticalImageProxy
from scilslab.feature_table import make_feature_names
from scilslab.session import LocalSession
from scilslab.types import FileInfo
from scilslab.types import Image
from scilslab.types import IonIntensities
from scilslab.types import Label
from scilslab.types import OpticalImage
from scilslab.types import ExternalImage
from scilslab.types import Point
from scilslab.types import Rectangle
from scilslab.types import RegionTree
from scilslab.types import RGBSpotImage
from scilslab.types import IntensitySpotImage
from scilslab.types import ScoreSpotImage
from scilslab.types import SpectraMatrix
